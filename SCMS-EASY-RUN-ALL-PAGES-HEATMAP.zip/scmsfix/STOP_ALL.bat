@echo off
echo Stopping SCMS Node processes...
taskkill /F /IM node.exe >nul 2>&1
echo SCMS processes stopped.
pause
