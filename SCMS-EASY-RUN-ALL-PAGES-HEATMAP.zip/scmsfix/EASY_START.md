# SCMS - Easiest Way To Run

## Windows
1. Extract the ZIP.
2. Make sure Node.js and MongoDB are installed. MongoDB can be local or you can put an Atlas URI in `backend/.env`.
3. Double-click **START_ALL.bat**.
4. Wait for the browser to open.
5. If it does not open automatically, visit **http://localhost:3000/demo**.

The `/demo` page gives one-click links to the Home, About, Services, Workflow, Technology, Contact, Sign In, Sign Up, Citizen Dashboard, Staff Dashboard, Admin Dashboard, complaint history, tracking, profile and the real heatmap.

## Heatmap
Open:
**http://localhost:3000/admin?demo=1&tab=heatmap**

The demo heatmap has sample Chennai, Coimbatore, Madurai and Puducherry complaint coordinates, so it is visible even before real complaints are stored.

## Backend check
Open **http://localhost:5000/** or **http://localhost:5000/api/health**.

## Stop
Double-click **STOP_ALL.bat**.

## Normal login
For real authentication and real complaint data, start MongoDB, then use the Sign In page. The demo links are only for quickly viewing every page and the UI.
