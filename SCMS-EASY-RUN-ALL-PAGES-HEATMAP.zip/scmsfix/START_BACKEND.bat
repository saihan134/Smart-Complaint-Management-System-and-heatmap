@echo off
setlocal
cd /d "%~dp0backend"
if not exist .env (
  echo Creating backend/.env from .env.example...
  copy /Y .env.example .env >nul
)
echo.
echo ============================================
echo   SCMS Backend
echo ============================================
echo.
echo Installing backend dependencies...
npm.cmd install
if errorlevel 1 (
  echo.
  echo ERROR: npm install failed.
  pause
  exit /b 1
)
echo.
echo Starting backend on http://localhost:5000 ...
echo Keep this window OPEN while using the frontend.
echo.
npm.cmd start
pause
