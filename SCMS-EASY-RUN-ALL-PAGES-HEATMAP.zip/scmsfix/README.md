# Smart Complaint Management System (SCMS)

A React + Node.js + Express + MongoDB complaint management system with Citizen, Staff and Admin dashboards.

## Project structure

- `frontend/` - React application
- `backend/` - Express REST API
- `backend/uploads/` - local complaint file uploads

## Requirements

- Node.js LTS
- MongoDB (local MongoDB service or MongoDB Atlas)
- VS Code

## First-time setup

### Backend

1. Open a terminal in `backend/`.
2. Copy `.env.example` to `.env`.
3. Set `MONGO_URI` and `JWT_SECRET`.
4. Run `npm install`.
5. Run `npm start`.

### Frontend

1. Open another terminal in `frontend/`.
2. Run `npm install`.
3. Run `npm start`.

The React development server uses the frontend `proxy` setting to send `/api` requests to `http://localhost:5000`.

## URLs

- Frontend: http://localhost:3000
- Backend: http://localhost:5000
- API health: http://localhost:5000/api/health

## Public project pages

- `/about`
- `/services`
- `/workflow`
- `/technology`
- `/contact`

## Application pages

- `/login`
- `/register`
- `/citizen`
- `/staff`
- `/admin`
- `/complaint-history`
- `/track-complaint`
- `/profile`

If PowerShell blocks `npm.ps1`, run `npm.cmd install` and `npm.cmd start`, or set the CurrentUser execution policy to `RemoteSigned`.

## Troubleshooting: Proxy error / ECONNREFUSED

If the browser shows:

`Proxy error: Could not proxy request /api/... from localhost:3000 to http://localhost:5000/ (ECONNREFUSED)`

this means the React frontend cannot reach the Node/Express backend on port 5000. The frontend proxy is already configured correctly.

### Correct startup order on Windows

1. Make sure MongoDB is running. For local MongoDB, start the MongoDB service or `mongod`.
2. Double-click `START_BACKEND.bat` and **keep that window open**.
3. Wait for `SCMS backend running at http://localhost:5000` and `MongoDB connected`.
4. Open a second terminal/window and run `START_FRONTEND.bat`.
5. Open `http://localhost:3000`.
6. Test `http://localhost:5000/api/health`. It should return JSON and show `database: "connected"`.

### If MongoDB is not installed

Install MongoDB Community Server, or replace `MONGO_URI` in `backend/.env` with your MongoDB Atlas connection string. Do not commit your real Atlas password or `.env` file.

### Important

The backend was changed so it **does not immediately exit when MongoDB is temporarily unavailable**. It keeps port 5000 alive and retries the MongoDB connection every 5 seconds. This removes the misleading `ECONNREFUSED` proxy failure and makes the actual database problem visible in the backend terminal.

## Real Geographic Complaint Heatmap

The admin dashboard now includes a real Leaflet/OpenStreetMap heatmap. It uses complaint latitude/longitude when available and automatically geocodes existing location names with OpenStreetMap Nominatim when coordinates are missing.

### First run after this update

```bash
cd frontend
npm install
npm start
```

The frontend dependencies now include `leaflet` and `leaflet.heat`.

### What was changed

- `frontend/src/Components/ComplaintHeatmap.jsx` — interactive map + heat layer + complaint popups.
- `frontend/src/Styles/ComplaintHeatmap.css` — map styling.
- `frontend/src/Dashboards/AdminDashboard.jsx` — real heatmap preview and full Heatmap tab.
- `frontend/src/Components/ComplaintFormModal.jsx` — captures browser GPS coordinates for Auto-Detect complaints.
- `backend/models/Complaint.js` — stores optional `coordinates.lat` and `coordinates.lng`.
- `backend/routes/complaints.js` — saves submitted latitude/longitude.

The heatmap is based on Leaflet.heat, which supports `[latitude, longitude, intensity]` points and configurable radius/blur/gradient. See the package documentation: https://www.npmjs.com/package/leaflet.heat
