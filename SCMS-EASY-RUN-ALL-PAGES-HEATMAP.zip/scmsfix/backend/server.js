const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');
const authRoutes = require('./routes/auth');
const complaintRoutes = require('./routes/complaints');
const userRoutes = require('./routes/users');
const analyticsRoutes = require('./routes/analytics');
const locations = require('./config/locations');

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:3000';

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

app.get('/api/locations', (req, res) => {
  res.json(locations);
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'SCMS API', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});

app.get('/', (req, res) => {
  const db = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
  res.send(`<!doctype html><html><head><meta charset="utf-8"><title>SCMS Backend</title><style>body{font-family:Arial;background:#f4f7fb;margin:0;padding:40px;color:#172033}main{max-width:760px;margin:auto;background:white;padding:35px;border-radius:18px;box-shadow:0 10px 30px #0001}a{display:inline-block;margin:8px 8px 8px 0;padding:12px 16px;background:#eef4ff;border-radius:10px;color:#175cd3;text-decoration:none}</style></head><body><main><h1>SCMS Backend is Running ✅</h1><p>Express API is listening on port ${PORT}.</p><p>MongoDB: <b>${db}</b></p><a href="/api/health">API Health</a><a href="http://localhost:3000/demo">Open All Frontend Pages</a><a href="/api/locations">Locations API</a></main></body></html>`);
});

app.use('/api/auth', authRoutes);
app.use('/api/complaints', complaintRoutes);
app.use('/api/users', userRoutes);
app.use('/api/analytics', analyticsRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
});

let server;

function startHttpServer() {
  if (server) return;

  server = app.listen(PORT, () => {
    console.log(`SCMS backend running at http://localhost:${PORT}`);
    console.log(`Frontend expected at ${FRONTEND_URL}`);
    console.log(`Health check: http://localhost:${PORT}/api/health`);
  });

  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use. Close the other SCMS backend or change PORT in backend/.env.`);
    } else {
      console.error('HTTP server error:', error);
    }
  });
}

async function connectMongoWithRetry() {
  const mongoUri = process.env.MONGO_URI;

  if (!mongoUri) {
    console.error('MONGO_URI is missing. Create backend/.env from backend/.env.example.');
    console.error('The API server will stay online, but database-backed requests will not work until MONGO_URI is configured.');
    return;
  }

  try {
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000
    });
    console.log('MongoDB connected');
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    console.error('SCMS backend is still running on port ' + PORT + '. Start MongoDB or update backend/.env with a valid MongoDB URI.');
    setTimeout(connectMongoWithRetry, 5000);
  }
}

startHttpServer();
connectMongoWithRetry();
