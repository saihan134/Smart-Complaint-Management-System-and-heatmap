const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const PDFDocument = require('pdfkit');

// GET /api/analytics/summary
router.get('/summary', async (req, res) => {
  try {
    // Get counts for different statuses
    const statusDistribution = await Complaint.aggregate([
      {
        $group: {
          _id: "$status",
          count: { $sum: 1 }
        }
      }
    ]);

    // Get complaints trend for last 30 days
    const complaintsTrend = await Complaint.aggregate([
      {
        $match: {
          createdAt: {
            $gte: new Date(new Date().setDate(new Date().getDate() - 30))
          }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    // Get category distribution
    const categoryDistribution = await Complaint.aggregate([
      {
        $group: {
          _id: "$category",
          count: { $sum: 1 }
        }
      }
    ]);

    // Get average resolution time
    const resolutionTime = await Complaint.aggregate([
      { $match: { status: "Resolved" } },
      {
        $project: {
          resolutionTime: {
            $divide: [
              { $subtract: ["$updatedAt", "$createdAt"] },
              1000 * 60 * 60 * 24 // ms to days
            ]
          }
        }
      },
      {
        $group: {
          _id: null,
          averageResolutionTime: { $avg: "$resolutionTime" }
        }
      }
    ]);

    // Get location data for heatmap
    const locationData = await Complaint.aggregate([
      {
        $group: {
          _id: "$location",
          count: { $sum: 1 },
          coordinates: { $first: "$coordinates" } // Assuming you have coordinates field
        }
      },
      { $match: { coordinates: { $exists: true } } }
    ]);

    res.json({
      statusDistribution,
      complaintsTrend,
      categoryDistribution,
      averageResolutionTime: resolutionTime[0]?.averageResolutionTime || 0,
      locationData
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch analytics data' });
  }
});

// GET /api/analytics/custom-report
router.get('/custom-report', async (req, res) => {
  try {
    const { timePeriod, reportType, format } = req.query;

    let dateFilter = {};
    if (timePeriod === '7days') {
      dateFilter = { $gte: new Date(new Date().setDate(new Date().getDate() - 7)) };
    } else if (timePeriod === '30days') {
      dateFilter = { $gte: new Date(new Date().setDate(new Date().getDate() - 30)) };
    } else if (timePeriod === 'quarter') {
      dateFilter = { $gte: new Date(new Date().setMonth(new Date().getMonth() - 3)) };
    }

    let aggregationPipeline = [];

    if (Object.keys(dateFilter).length > 0) {
      aggregationPipeline.push({ $match: { createdAt: dateFilter } });
    }

    switch (reportType) {
      case 'complaints-summary':
        aggregationPipeline.push({
          $group: {
            _id: null,
            totalComplaints: { $sum: 1 },
            resolved: { $sum: { $cond: [{ $eq: ["$status", "Resolved"] }, 1, 0] } },
            inProgress: { $sum: { $cond: [{ $eq: ["$status", "In Progress"] }, 1, 0] } },
            pending: { $sum: { $cond: [{ $eq: ["$status", "Pending"] }, 1, 0] } }
          }
        });
        break;

      case 'staff-performance':
        aggregationPipeline.push({
          $group: {
            _id: "$assignedTo",
            totalAssigned: { $sum: 1 },
            resolved: { $sum: { $cond: [{ $eq: ["$status", "Resolved"] }, 1, 0] } }
          }
        });
        break;

      case 'category-analysis':
        aggregationPipeline.push({
          $group: {
            _id: "$category",
            total: { $sum: 1 },
            resolved: { $sum: { $cond: [{ $eq: ["$status", "Resolved"] }, 1, 0] } }
          }
        });
        break;

      case 'location-analysis':
        aggregationPipeline.push({
          $group: {
            _id: "$location",
            total: { $sum: 1 }
          }
        });
        break;

      default:
        return res.status(400).json({ error: 'Invalid report type' });
    }

    const result = await Complaint.aggregate(aggregationPipeline);

    // Handle simple PDF generation
  if (format === 'pdf') {
  const doc = new PDFDocument();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="report.pdf"');
  doc.pipe(res);

  // Title
  doc.fontSize(18).text('Custom Report', { align: 'center' });
  doc.moveDown();

  if (!result || result.length === 0) {
    doc.fontSize(14).text('No data found for the selected report and time period.', { align: 'center' });
    doc.end();
    return;
  }

  result.forEach((item, index) => {
    doc.fontSize(14).fillColor('black').text(`Record ${index + 1}`, { underline: true });
    doc.moveDown(0.5);

    Object.entries(item).forEach(([key, value]) => {
      if (key === '_id' && (value === null || typeof value !== 'string')) return; // skip _id unless it's meaningful

      // Convert camelCase to Title Case
      const formattedKey = key
        .replace(/([A-Z])/g, ' $1')   // insert space before capital letters
        .replace(/^./, str => str.toUpperCase()); // capitalize first letter

      doc.fontSize(12).text(`${formattedKey}: ${value}`);
    });

    doc.moveDown();
  });

  doc.end();
  return;
}


    // Default: return JSON
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate report' });
  }
});

module.exports = router;