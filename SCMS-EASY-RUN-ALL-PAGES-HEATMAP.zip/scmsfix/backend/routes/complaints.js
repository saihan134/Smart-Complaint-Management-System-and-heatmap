const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');

// Cloudinary + multer setup
const upload = require('../middleware/cloudinaryStorage');

// POST /api/complaints
router.post('/', upload.array('files', 5), async (req, res) => {
  try {
    const {
      title,
      category,
      description,
      location,
      locationType,
      latitude,
      longitude,
      date,
      userId, // This should come from frontend or JWT
    } = req.body;

    if (!title || !category || !description || !location || !date || !userId) {
      return res.status(400).json({ message: 'All required fields must be filled' });
    }

    // Extract file URLs from Cloudinary response
    const fileUrls = (req.files || []).map(file => `/uploads/${file.filename}`);

    const complaint = new Complaint({
      title,
      category,
      description,
      location,
      locationType,
      latitude,
      longitude,
      date,
      files: fileUrls,
      userId,
      status: 'Pending'
    });

    await complaint.save();
    res.status(201).json({ message: 'Complaint submitted successfully', complaint });
  } catch (error) {
    console.error('Error saving complaint:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET complaints by user (citizen)
router.get('/citizen/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const complaints = await Complaint.find({ userId }).sort({ date: -1 });

    res.status(200).json(complaints);
  } catch (error) {
    console.error('Error fetching complaints:', error);
    res.status(500).json({ message: 'Server error fetching complaints' });
  }
});


// GET /api/complaints/stats/:userId
router.get('/stats/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const total = await Complaint.countDocuments({ userId });
    const resolved = await Complaint.countDocuments({ userId, status: 'Resolved' });
    const inProgress = await Complaint.countDocuments({ userId, status: 'In Progress' });

    res.status(200).json({ total, resolved, inProgress });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/', async (req, res) => {
  try {
    const complaints = await Complaint.find().sort({ createdAt: -1 }); // newest first
    res.status(200).json(complaints);
  } catch (error) {
    console.error('Error fetching complaints:', error);
    res.status(500).json({ message: 'Server error while fetching complaints' });
  }
});


router.put('/:id/update-status', async (req, res) => {
  try {
    const complaintId = req.params.id;
    const { status, remarkMessage } = req.body;

    if (!status) {
      return res.status(400).json({ message: 'Status is required' });
    }

    const complaint = await Complaint.findById(complaintId);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    // Update status
    complaint.status = status;

    // Add remark if provided
    if (remarkMessage && remarkMessage.trim() !== '') {
      complaint.remarks.push({
        message: remarkMessage,
        seen: false, // For notification to citizen
        timestamp: new Date()
      });
    }

    await complaint.save();

    res.status(200).json({ message: 'Complaint updated successfully', complaint });
  } catch (error) {
    console.error('Error updating complaint status:', error);
    res.status(500).json({ message: 'Server error while updating complaint' });
  }
});


// GET /api/notifications/:userId
router.get('/notifications/:userId', async (req, res) => {
  try {
    const complaints = await Complaint.find({ userId: req.params.userId });

    const newRemarks = [];

    complaints.forEach(complaint => {
      complaint.remarks.forEach(remark => {
        if (!remark.seen) {
          newRemarks.push({
            complaintId: complaint._id,
            title: complaint.title,
            seen: remark.seen,
            status: complaint.status,
            message: remark.message,
            timestamp: remark.timestamp
          });
        }
      });
    });

    res.json(newRemarks);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching notifications' });
  }
});


// PATCH /api/complaints/:id/mark-seen
router.patch('/:id/mark-seen', async (req, res) => {
  try {
    const complaintId = req.params.id;

    // Set all unseen remarks' seen = true
    const complaint = await Complaint.findById(complaintId);
    if (!complaint) return res.status(404).json({ message: 'Complaint not found' });

    let updated = false;
    complaint.remarks = complaint.remarks.map(r => {
      if (!r.seen) {
        r.seen = true;
        updated = true;
      }
      return r;
    });

    if (updated) await complaint.save();

    res.json({ message: 'All unseen remarks marked as seen' });
  } catch (err) {
    console.error('Error marking remarks as seen:', err);
    res.status(500).json({ message: 'Server error' });
  }
});



router.get('/:id', async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id).populate('userId', 'fullName email location');
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    res.json(complaint);
  } catch (error) {
    console.error('Error fetching complaint:', error);
    res.status(500).json({ message: 'Server error while fetching complaint' });
  }
});


router.patch('/notifications/mark-all-seen/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const result = await Complaint.updateMany(
      { userId, "remarks.seen": false },
      {
        $set: { "remarks.$[elem].seen": true }
      },
      {
        arrayFilters: [{ "elem.seen": false }]
      }
    );

    res.status(200).json({ message: 'All remarks marked as seen', modifiedCount: result.modifiedCount });
  } catch (error) {
    console.error('Error marking remarks as seen:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});


// GET /api/complaints/unseen/:location
router.get('/unseen/:location', async (req, res) => {
  try {
    const { location } = req.params;
    const unseenComplaints = await Complaint.find({ location, seen: false }).populate('userId', 'fullName email');
    res.json(unseenComplaints);
  } catch (error) {
    console.error('Error fetching unseen complaints:', error);
    res.status(500).json({ message: 'Server error' });
  }
});


// PUT /api/complaints/mark-seen/:id
router.put('/mark-seen/:id', async (req, res) => {
  try {
    const complaintId = req.params.id;

    const updatedComplaint = await Complaint.findByIdAndUpdate(
      complaintId,
      { seen: true },
      { new: true }
    );

    if (!updatedComplaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    res.json({ message: 'Complaint marked as seen', complaint: updatedComplaint });
  } catch (error) {
    console.error('Error marking complaint as seen:', error);
    res.status(500).json({ message: 'Server error' });
  }
});



router.put('/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["Pending", "In Progress", "Resolved"].includes(status)) {
    return res.status(400).json({ error: "Invalid status value" });
  }

  try {
    const updatedComplaint = await Complaint.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    if (!updatedComplaint) {
      return res.status(404).json({ error: "Complaint not found" });
    }

    res.json(updatedComplaint);
  } catch (err) {
    console.error('Error updating complaint status:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


// ✅ Delete a complaint by ID
router.delete('/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const deletedComplaint = await Complaint.findByIdAndDelete(id);

    if (!deletedComplaint) {
      return res.status(404).json({ error: 'Complaint not found' });
    }

    res.json({ message: 'Complaint deleted successfully' });
  } catch (err) {
    console.error('Error deleting complaint:', err);
    res.status(500).json({ error: 'Server error' });
  }
});





module.exports = router;
