const mongoose = require("mongoose");

const remarkSchema = new mongoose.Schema({
  message: { type: String },
  seen: { type: Boolean, default: false },
  timestamp: { type: Date, default: Date.now },
});

const complaintSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    category: { type: String, required: true },
    description: { type: String, required: true },
    location: { type: String, required: true },
    coordinates: {
      lat: { type: Number },
      lng: { type: Number }
    },
    locationType: { type: String, enum: ["manual", "auto"], default: "manual" },
    date: { type: Date, required: true },
    files: [String], // File names or URLs
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    status: {
      type: String,
      enum: ["Pending", "In Progress", "Resolved"],
      default: "Pending",
    },
    remarks: [remarkSchema],
    seen: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Complaint", complaintSchema);
