const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'xxxxxxxxxx', //replace your details
  api_key: 'xxxxxxxxxxxxxx',
  api_secret: 'xxxxxxxxxxxxxxx',
});

module.exports = cloudinary;
