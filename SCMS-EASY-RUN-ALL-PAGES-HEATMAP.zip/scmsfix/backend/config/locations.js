module.exports = [
  {
    "name": "Chennai",
    "latitude": 13.0827,
    "longitude": 80.2707
  },
  {
    "name": "Coimbatore",
    "latitude": 11.0168,
    "longitude": 76.9558
  },
  {
    "name": "Madurai",
    "latitude": 9.9252,
    "longitude": 78.1198
  },
  {
    "name": "Tiruchirappalli",
    "latitude": 10.7905,
    "longitude": 78.7047
  },
  {
    "name": "Salem",
    "latitude": 11.6643,
    "longitude": 78.146
  },
  {
    "name": "Tirunelveli",
    "latitude": 8.7139,
    "longitude": 77.7567
  },
  {
    "name": "Tenkasi",
    "latitude": 8.9597,
    "longitude": 77.3152
  },
  {
    "name": "Sankarankoil",
    "latitude": 9.1756,
    "longitude": 77.5437
  },
  {
    "name": "Thoothukudi",
    "latitude": 8.7642,
    "longitude": 78.1348
  },
  {
    "name": "Vellore",
    "latitude": 12.9165,
    "longitude": 79.1325
  },
  {
    "name": "Erode",
    "latitude": 11.341,
    "longitude": 77.7172
  },
  {
    "name": "Thanjavur",
    "latitude": 10.787,
    "longitude": 79.1378
  }
];
