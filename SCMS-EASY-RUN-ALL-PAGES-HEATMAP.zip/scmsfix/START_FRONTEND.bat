@echo off
setlocal
cd /d "%~dp0frontend"
echo.
echo ============================================
echo   SCMS Frontend
echo ============================================
echo.
echo Installing frontend dependencies...
npm.cmd install
if errorlevel 1 (
  echo.
  echo ERROR: npm install failed.
  pause
  exit /b 1
)
echo.
echo Starting frontend on http://localhost:3000 ...
echo Keep the backend window OPEN too.
echo.
npm.cmd start
pause
