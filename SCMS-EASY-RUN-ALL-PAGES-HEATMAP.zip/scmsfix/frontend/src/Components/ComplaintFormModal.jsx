import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import '../Styles/ComplaintForm.css';
import axios from 'axios';

const ComplaintFormModal = ({ show, onHide }) => {
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    description: '',
    location: '',
    locationType: 'manual', // 'manual' or 'auto'
    date: new Date().toISOString().split('T')[0],
    files: [],
    termsAgreed: false,
    latitude: '',
    longitude: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = [
    'Road Issues (e.g., potholes)',
    'Waste Management',
    'Streetlight / Electrical',
    'Water Supply',
    'Noise Pollution',
    'Sanitation',
    'Other'
  ];

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : 
              type === 'file' ? Array.from(files) : value
    });

    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  const user = JSON.parse(localStorage.getItem('user'));
  const userLocation =user?.location;

  const handleLocationTypeChange = (type) => {
    if (type === 'auto' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => setFormData(prev => ({ ...prev, locationType: 'auto', location: userLocation || `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`, latitude: position.coords.latitude, longitude: position.coords.longitude })),
        () => setFormData(prev => ({ ...prev, locationType: 'auto', location: userLocation || '' })),
        { enableHighAccuracy: true, timeout: 10000 }
      );
    } else {
      setFormData(prev => ({ ...prev, locationType: type, location: type === 'auto' ? userLocation || '' : '', latitude: '', longitude: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.category) newErrors.category = 'Category is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.termsAgreed) newErrors.termsAgreed = 'You must agree to the terms';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

 const handleSubmit = async (e) => {
  e.preventDefault();

  const userId = user?.id;
  const location =user?.location;

  if (!userId) {
    alert("User not found. Please login again.");
    return;
  }

  if (validate()) {
    setIsSubmitting(true);

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('title', formData.title);
      formDataToSend.append('category', formData.category);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('location', formData.location);
      formDataToSend.append('locationType', formData.locationType);
      if (formData.latitude !== '') formDataToSend.append('latitude', formData.latitude);
      if (formData.longitude !== '') formDataToSend.append('longitude', formData.longitude);
      formDataToSend.append('date', formData.date);
      formDataToSend.append('userId', userId);

      // Append each selected file
      formData.files.forEach(file => {
        formDataToSend.append('files', file);
      });

      const response = await fetch('/api/complaints', {
        method: 'POST',
        body: formDataToSend, // No need to set Content-Type for FormData
      });

      const data = await response.json();

      if (response.ok) {
        alert('Complaint submitted successfully!');
        onHide();
      } else {
        alert(data.message || 'Complaint submission failed');
      }
    } catch (error) {
      console.error('Submission error:', error);
      alert('Server error. Please try again later.');
    } finally {
      setIsSubmitting(false);
    }
  }
};



  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>Report New Municipal Issue</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <form onSubmit={handleSubmit}>
          {/* Complaint Title */}
          <div className={`form-group ${errors.title ? 'has-error' : ''}`}>
            <label htmlFor="title">Complaint Title*</label>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="Brief summary of the issue"
              maxLength="100"
            />
            {errors.title && <span className="error-message">{errors.title}</span>}
            <small className="helper-text">e.g., "Overflowing Garbage Bin near Market Road"</small>
          </div>

          {/* Category */}
          <div className={`form-group ${errors.category ? 'has-error' : ''}`}>
            <label htmlFor="category">Category*</label>
            <select
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
            >
              <option value="">Select a category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {errors.category && <span className="error-message">{errors.category}</span>}
          </div>

          {/* Description */}
          <div className={`form-group ${errors.description ? 'has-error' : ''}`}>
            <label htmlFor="description">Description*</label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Please describe the issue in detail"
              rows="4"
            ></textarea>
            {errors.description && <span className="error-message">{errors.description}</span>}
          </div>

          {/* Location */}
          <div className={`form-group ${errors.location ? 'has-error' : ''}`}>
            <label>Location*</label>
            <div className="location-options">
              <button
                type="button"
                className={`location-toggle ${formData.locationType === 'manual' ? 'active' : ''}`}
                onClick={() => handleLocationTypeChange('manual')}
              >
                <i className="fas fa-map-marker-alt"></i> Enter Address
              </button>
              <button
                type="button"
                className={`location-toggle ${formData.locationType === 'auto' ? 'active' : ''}`}
                onClick={() => handleLocationTypeChange('auto')}
      disabled={!userLocation}
              >
                <i className="fas fa-location-arrow"></i> Auto-Detect
              </button>
            </div>
            {formData.locationType === 'manual' ? (
                <select
    name="location"
    value={formData.location}
    onChange={handleChange}
    className="form-select"
  >
    <option value="">Select your area</option>
    <option value="Tenkasi">Tenkasi</option>
    <option value="Sankarankoil">Sankarankoil</option>
  </select>
            ) : (
              <div className="auto-location">
                <i className="fas fa-check-circle"></i> {userLocation}
              </div>
            )}
            {errors.location && <span className="error-message">{errors.location}</span>}
          </div>

          {/* Date */}
          <div className="form-group">
            <label htmlFor="date">Date of Issue</label>
            <input
              type="date"
              id="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
            />
          </div>

          {/* File Upload */}
          <div className="form-group">
            <label>Upload Evidence (Optional)</label>
            <div className="file-upload">
              <label htmlFor="file-upload" className="upload-btn">
                <i className="fas fa-cloud-upload-alt"></i> Choose Files
                <input
                  id="file-upload"
                  type="file"
                  name="files"
                  onChange={handleChange}
                  multiple
                  accept="image/*,video/*"
                  style={{ display: 'none' }}
                />
              </label>
              <span className="file-info">
                {formData.files.length > 0 
                  ? `${formData.files.length} file(s) selected` 
                  : 'Images (max 5MB each)'}
              </span>
            </div>
            {formData.files.length > 0 && (
              <div className="file-preview">
                {formData.files.map((file, index) => (
                  <div key={index} className="file-item">
                    <i className="fas fa-file-image"></i> {file.name}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Terms Agreement */}
          <div className={`form-group checkbox-group ${errors.termsAgreed ? 'has-error' : ''}`}>
            <input
              type="checkbox"
              id="termsAgreed"
              name="termsAgreed"
              checked={formData.termsAgreed}
              onChange={handleChange}
            />
            <label htmlFor="termsAgreed">
              I confirm the information provided is true and accurate.*
            </label>
            {errors.termsAgreed && <span className="error-message">{errors.termsAgreed}</span>}
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={onHide}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  Submitting...
                </>
              ) : (
                'Submit Complaint'
              )}
            </button>
          </div>
        </form>
      </Modal.Body>
    </Modal>
  );
};

export default ComplaintFormModal;