import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../Styles/TrackComplaint.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const TrackComplaint = () => {
  const [complaint, setComplaint] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [userComplaints, setUserComplaints] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const { complaintId } = useParams();

  useEffect(() => {
    const fetchUserComplaints = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        const userId = user?.id;
        
        const response = await fetch(`/api/complaints/citizen/${userId}`);
        const data = await response.json();
        
        if (response.ok) {
          setUserComplaints(data);
          // If complaintId is in URL, load that complaint
          if (complaintId) {
            const foundComplaint = data.find(c => c._id === complaintId);
            if (foundComplaint) {
              setComplaint(foundComplaint);
              setSearchInput(foundComplaint._id);
            }
          }
        }
      } catch (error) {
        console.error('Error fetching complaints:', error);
      }
    };

    fetchUserComplaints();
  }, [complaintId]);

  const handleSearch = async () => {
    if (!searchInput.trim()) return;
    
    setIsLoading(true);
    try {
      // First check if it's in the user's complaints
      const foundComplaint = userComplaints.find(c => 
        c._id.includes(searchInput) || 
        c.title.toLowerCase().includes(searchInput.toLowerCase())
      );
      
      if (foundComplaint) {
        setComplaint(foundComplaint);
      } else {
        // If not found in local list, try API
        const response = await fetch(`/api/complaints/${searchInput}`);
        const data = await response.json();
        
        if (response.ok) {
          setComplaint(data);
        } else {
          alert('Complaint not found. Please check the ID and try again.');
        }
      }
    } catch (error) {
      console.error('Error searching complaint:', error);
      alert('An error occurred while searching for the complaint.');
    } finally {
      setIsLoading(false);
      setShowDropdown(false);
    }
  };

  const statusBadge = (status) => {
    const statusClasses = {
      'Pending': 'badge-warning',
      'In Progress': 'badge-info',
      'Resolved': 'badge-success'
    };
    return <span className={`badgee ${statusClasses[status]}`}>{status}</span>;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusProgress = (status) => {
    switch(status) {
      case 'Pending': return 33;
      case 'In Progress': return 66;
      case 'Resolved': return 100;
      default: return 0;
    }
  };

  return (
    <div className="track-complaint">
      <div className="container">
        <div className="page-header">
          <h1>Track Complaint Status</h1>
          <p>Check the current status and updates for your municipal complaint</p>
        </div>

        <div className="search-section">
          <div className="search-container">
            <div className="search-input-wrapper">
              <i className="fas fa-search"></i>
              <input
                type="text"
                placeholder="Enter Complaint ID or Title (e.g., COMP-2023-001)"
                value={searchInput}
                onChange={(e) => {
                  setSearchInput(e.target.value);
                  setShowDropdown(e.target.value.length > 0);
                }}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button 
                className="search-btn"
                onClick={handleSearch}
                disabled={isLoading}
              >
                {isLoading ? 'Searching...' : 'Search'}
              </button>
            </div>
            
            {showDropdown && userComplaints.length > 0 && (
              <div className="complaints-dropdown">
                {userComplaints
                  .filter(c => 
                    c._id.includes(searchInput) || 
                    c.title.toLowerCase().includes(searchInput.toLowerCase())
                  )
                  .slice(0, 5)
                  .map(complaint => (
                    <div 
                      key={complaint._id}
                      className="dropdown-item"
                      onClick={() => {
                        setSearchInput(complaint._id);
                        setComplaint(complaint);
                        setShowDropdown(false);
                      }}
                    >
                      <div className="complaint-id">{complaint._id.substring(0, 8)}...</div>
                      <div className="complaint-title">{complaint.title}</div>
                      <div className="complaint-date">{formatDate(complaint.createdAt)}</div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>

        {complaint ? (
          <div className="complaint-details">
            <div className="detail-card">
              <h2 className="complaint-title">{complaint.title}</h2>
              <div className="detail-grid">
                <div className="detail-item">
                  <span className="detail-label">Complaint ID:</span>
                  <span className="detail-value">{complaint._id}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Category:</span>
                  <span className="detail-value">{complaint.category}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Submitted:</span>
                  <span className="detail-value">{formatDate(complaint.createdAt)}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Location:</span>
                  <span className="detail-value">{complaint.location}</span>
                </div>
              </div>
            </div>

            <div className="status-section">
              <h3>Current Status</h3>
              <div className="status-display">
                <div className="status-badge">
                  {statusBadge(complaint.status)}
                </div>
                <div className="progress-tracker">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill"
                      style={{ width: `${getStatusProgress(complaint.status)}%` }}
                    ></div>
                  </div>
                  <div className="progress-steps">
                    <div className={`step ${complaint.status === 'Pending' ? 'active' : ''}`}>
                      <div className="step-icon">1</div>
                      <div className="step-label">Submitted</div>
                    </div>
                    <div className={`step ${complaint.status === 'In Progress' ? 'active' : ''}`}>
                      <div className="step-icon">2</div>
                      <div className="step-label">In Progress</div>
                    </div>
                    <div className={`step ${complaint.status === 'Resolved' ? 'active' : ''}`}>
                      <div className="step-icon">3</div>
                      <div className="step-label">Resolved</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="timeline-section">
              <h3>Timeline</h3>
              <div className="timeline">
                <div className="timeline-item">
                  <div className="timeline-date">{formatDate(complaint.createdAt)}</div>
                  <div className="timeline-content">
                    <div className="timeline-title">Complaint Submitted</div>
                    <div className="timeline-desc">Your complaint was successfully submitted to the municipality.</div>
                  </div>
                </div>
                
                {complaint.status === 'In Progress' && (
                  <div className="timeline-item">
                    <div className="timeline-date">
                      {complaint.updatedAt ? formatDate(complaint.updatedAt) : '--'}
                    </div>
                    <div className="timeline-content">
                      <div className="timeline-title">Work Started</div>
                      <div className="timeline-desc">
                        {complaint.adminRemarks || 'Municipal staff has begun working on your complaint.'}
                      </div>
                    </div>
                  </div>
                )}
                
                {complaint.status === 'Resolved' && (
                  <div className="timeline-item">
                    <div className="timeline-date">
                      {complaint.resolvedAt ? formatDate(complaint.resolvedAt) : '--'}
                    </div>
                    <div className="timeline-content">
                      <div className="timeline-title">Complaint Resolved</div>
                      <div className="timeline-desc">
                        {complaint.resolutionNotes || 'Your complaint has been successfully resolved.'}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {complaint.files?.length > 0 && (
              <div className="attachments-section">
                <h3>Attached Evidence</h3>
                <div className="attachments-grid">
                  {complaint.files.map((file, index) => (
                    <div key={index} className="attachment-item">
                      {file.match(/\.(jpeg|jpg|gif|png)$/) ? (
                        <img src={file} alt={`Evidence ${index + 1}`} className="attachment-image" />
                      ) : (
                        <div className="attachment-file">
                          <i className="fas fa-file-alt"></i>
                          <span>Evidence {index + 1}</span>
                        </div>
                      )}
                      <a href={file} target="_blank" rel="noopener noreferrer" className="view-full">
                        View Full <i className="fas fa-external-link-alt"></i>
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="no-complaint">
            <div className="search-illustration">
              <i className="fas fa-search"></i>
            </div>
            <h3>Search for a Complaint</h3>
            <p>Enter your complaint ID or select from your recent complaints to view its status and updates.</p>
            {userComplaints.length > 0 && (
              <div className="recent-complaints">
                <h4>Your Recent Complaints:</h4>
                <div className="recent-list">
                  {userComplaints.slice(0, 3).map(complaint => (
                    <div 
                      key={complaint._id}
                      className="recent-item"
                      onClick={() => {
                        setSearchInput(complaint._id);
                        setComplaint(complaint);
                      }}
                    >
                      <div className="recent-id">{complaint._id.substring(0, 8)}...</div>
                      <div className="recent-title">{complaint.title}</div>
                      <div className="recent-status">{statusBadge(complaint.status)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TrackComplaint;