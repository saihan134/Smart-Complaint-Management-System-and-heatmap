import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../Styles/ComplaintHistory.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import ComplaintDetailsModal from '../Components/ComplaintDetailsModal';

const ComplaintHistory = () => {
  const [complaints, setComplaints] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const complaintsPerPage = 10;

  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        setIsLoading(true);
        const user = JSON.parse(localStorage.getItem('user'));
        const userId = user?.id;

        const response = await fetch(`/api/complaints/citizen/${userId}`);
        const data = await response.json();

        if (response.ok) {
          setComplaints(data);
        } else {
          console.error(data.message);
        }
      } catch (error) {
        console.error('Error fetching complaints:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchComplaints();
  }, []);

  const filteredComplaints = complaints.filter(complaint => 
    complaint.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    complaint.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    complaint.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination logic
  const indexOfLastComplaint = currentPage * complaintsPerPage;
  const indexOfFirstComplaint = indexOfLastComplaint - complaintsPerPage;
  const currentComplaints = filteredComplaints.slice(indexOfFirstComplaint, indexOfLastComplaint);
  const totalPages = Math.ceil(filteredComplaints.length / complaintsPerPage);

  const getStatusBadgeClass = (status) => {
    switch(status) {
      case 'Pending': return 'status-pending';
      case 'In Progress': return 'status-in-progress';
      case 'Resolved': return 'status-resolved';
      default: return '';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleViewDetails = (complaint) => {
    setSelectedComplaint(complaint);
    setShowDetailsModal(true);
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="complaint-history loading">
        <div className="spinner-container">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="complaint-history">
      {/* Complaint Details Modal */}
      {selectedComplaint && (
        <ComplaintDetailsModal 
          show={showDetailsModal}
          onHide={() => setShowDetailsModal(false)}
          complaint={selectedComplaint}
        />
      )}

      <div className="container">
        <div className="page-header">
          <h1>Your Complaint History</h1>
          <p>View all complaints you've submitted to the municipality</p>
        </div>

        <div className="complaint-tools">
          <div className="search-box">
            <i className="fas fa-search"></i>
            <input
              type="text"
              placeholder="Search complaints..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
          </div>
          <div className="total-complaints">
            <span className="count">{complaints.length}</span>
            <span className="label">Total Complaints</span>
          </div>
        </div>

        {currentComplaints.length > 0 ? (
          <>
            {/* Mobile Card View */}
            <div className="complaints-list">
              {currentComplaints.map((complaint) => (
                <div className="complaint-card" key={complaint._id}>
                  <div className="complaint-id">
                    <i className="fas fa-hashtag"></i>
                    {complaint._id.substring(0, 8)}
                  </div>
                  <div className="complaint-status">
                    <span className={`status-badge ${getStatusBadgeClass(complaint.status)}`}>
                      {complaint.status}
                    </span>
                  </div>
                  <h3 className="complaint-title">{complaint.title}</h3>
                  <div className="complaint-meta">
                    <div className="meta-item complaint-category">
                      <span className="meta-label">
                        <i className="fas fa-tag"></i> Category
                      </span>
                      <span className="meta-value">{complaint.category}</span>
                    </div>
                    <div className="meta-item">
                      <span className="meta-label">
                        <i className="fas fa-calendar"></i> Submitted
                      </span>
                      <span className="meta-value">{formatDate(complaint.createdAt)}</span>
                    </div>
                    {complaint.files?.length > 0 && (
                      <div className="meta-item">
                        <span className="meta-label">
                          <i className="fas fa-paperclip"></i> Attachments
                        </span>
                        <span className="meta-value">{complaint.files.length}</span>
                      </div>
                    )}
                  </div>
                  <div className="complaint-actions">
                    <button 
                      className="view-btn view-btn-primary"
                      onClick={() => handleViewDetails(complaint)}
                    >
                      <i className="fas fa-eye"></i> View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View (hidden on mobile) */}
            <div className="complaints-table">
              <div className="table-header">
                <div className="header-cell">Complaint ID</div>
                <div className="header-cell">Title</div>
                <div className="header-cell">Category</div>
                <div className="header-cell">Date Submitted</div>
                <div className="header-cell">Status</div>
                <div className="header-cell">Actions</div>
              </div>
              
              {currentComplaints.map((complaint) => (
                <div className="table-row" key={complaint._id}>
                  <div className="table-cell id-cell">
                    {complaint._id.substring(0, 8)}
                  </div>
                  <div className="table-cell title-cell">
                    <div className="title-text">{complaint.title}</div>
                    {complaint.files?.length > 0 && (
                      <span className="attachment-indicator">
                        <i className="fas fa-paperclip"></i> {complaint.files.length} attachment(s)
                      </span>
                    )}
                  </div>
                  <div className="table-cell category-cell">
                    <span className="category-badge">{complaint.category}</span>
                  </div>
                  <div className="table-cell date-cell">
                    {formatDate(complaint.createdAt)}
                  </div>
                  <div className="table-cell status-cell">
                    <span className={`status-badge ${getStatusBadgeClass(complaint.status)}`}>
                      {complaint.status}
                    </span>
                  </div>
                  <div className="table-cell action-cell">
                    <button 
                      className="view-btn view-btn-primary"
                      onClick={() => handleViewDetails(complaint)}
                    >
                      <i className="fas fa-eye"></i> View
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {totalPages > 1 && (
              <div className="pagination">
                <button
                  className={`page-btn ${currentPage === 1 ? 'disabled' : ''}`}
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  <i className="fas fa-chevron-left"></i> Previous
                </button>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(number => (
                  <button
                    key={number}
                    className={`page-btn ${currentPage === number ? 'active' : ''}`}
                    onClick={() => handlePageChange(number)}
                  >
                    {number}
                  </button>
                ))}
                
                <button
                  className={`page-btn ${currentPage === totalPages ? 'disabled' : ''}`}
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="no-complaints">
            {searchTerm ? (
              <>
                <i className="fas fa-search"></i>
                <h3>No matching complaints found</h3>
                <p>Try adjusting your search criteria</p>
                <button 
                  className="clear-search"
                  onClick={() => setSearchTerm('')}
                >
                  Clear search
                </button>
              </>
            ) : (
              <>
                <i className="fas fa-inbox"></i>
                <h3>You haven't submitted any complaints yet</h3>
                <p>Get started by reporting your first municipal issue</p>
                <Link to="/submit-complaint" className="view-btn view-btn-primary">
                  <i className="fas fa-plus"></i> Submit a Complaint
                </Link>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ComplaintHistory;