import { useState, useEffect } from 'react';
import axios from 'axios';
import '../Styles/ProfilePage.css';

const ProfilePage = () => {
  const [profileData, setProfileData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    location: '',
    role: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [stats, setStats] = useState({ total: 0, resolved: 0, inProgress: 0 });

  const user = JSON.parse(localStorage.getItem('user'));
  const userId =user?.id;
  useEffect(() => {
    const fetchProfileData = async () => {
      try {
        const response = await axios.get(`/api/users/${userId}`);
        setProfileData(response.data);
        setIsLoading(false);
      } catch (err) {
        setError('Failed to fetch profile data');
        setIsLoading(false);
      }
    };
    fetchProfileData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const fetchStats = async () => {
  try {
    const res = await axios.get(`/api/complaints/stats/${userId}`);
    setStats(res.data);
  } catch (err) {
    console.error('Error fetching stats:', err);
  }
};

fetchStats();

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(profileData);
    try {
  const response = await axios.put(
    `/api/users/${userId}`,
    profileData,
    {
      headers: {
        'Content-Type': 'application/json',
      },
    }
  );

  setProfileData(response.data);
  setIsEditing(false);
  setSuccessMessage('Profile updated successfully!');
  setTimeout(() => setSuccessMessage(''), 3000);
} catch (err) {
      setError('Failed to update profile');
    }
  };

  if (isLoading) return <div className="loading-spiral"></div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div className="profile-container">
      <div className="profile-background-shapes">
        <div className="shape-1"></div>
        <div className="shape-2"></div>
        <div className="shape-3"></div>
      </div>
      
      <div className="profile-header">
        <div className="profile-avatar">
          <div className="avatar-circle">
            {profileData?.fullName?.charAt(0)?.toUpperCase() || 'U'}

          </div>
          <div className="avatar-ring"></div>
        </div>
        <h1 className="profile-title">{profileData.fullName}</h1>
        <p className="profile-role">{profileData.role}</p>
      </div>

      <div className="profile-content">
        <div className="profile-card profile-card-main">
          <div className="card-header">
            <h2>Personal Information</h2>
            {!isEditing && (
              <button 
                className="edit-button"
                onClick={() => setIsEditing(true)}
              >
                Edit Profile
              </button>
            )}
          </div>
          
          {isEditing ? (
            <form onSubmit={handleSubmit} className="profile-form">
              <div className="form-group floating">
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  value={profileData.fullName}
                  onChange={handleInputChange}
                  required
                />
                <label htmlFor="fullName">Full Name</label>
              </div>
              
              <div className="form-group floating">
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={profileData.email}
                  onChange={handleInputChange}
                  required
                />
                <label htmlFor="email">Email</label>
              </div>
              
              <div className="form-group floating">
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={profileData.phone}
                  onChange={handleInputChange}
                  required
                />
                <label htmlFor="phone">Phone</label>
              </div>
              
              <div className="form-group floating">
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={profileData.location}
                  onChange={handleInputChange}
                  required
                />
                <label htmlFor="location">Location</label>
              </div>
              
              <div className="form-group floating">
                <textarea
                  id="address"
                  name="address"
                  value={profileData.address}
                  onChange={handleInputChange}
                  required
                />
                <label htmlFor="address">Address</label>
              </div>
              
              <div className="form-actions">
                <button
                  type="button"
                  className="cancel-button"
                  onClick={() => setIsEditing(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="save-button">
                  Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div className="profile-details">
              <div className="detail-item">
                <span className="detail-label">Email</span>
                <span className="detail-value">{profileData.email}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Phone</span>
                <span className="detail-value">{profileData.phone}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Location</span>
                <span className="detail-value">{profileData.location}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Address</span>
                <span className="detail-value multiline">{profileData.address}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Member Since</span>
                <span className="detail-value">
                  {new Date(profileData.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          )}
          
          {successMessage && (
            <div className="success-message">
              {successMessage}
            </div>
          )}
        </div>

        <div className="profile-card profile-card-stats">
          <h2>Activity Stats</h2>
          <div className="stats-container">
            <div className="stat-item">
              <div className="stat-circle">
                <span>{stats.total}</span>
              </div>
              <p>Complaints Filed</p>
            </div>
            <div className="stat-item">
              <div className="stat-circle">
                <span>{stats.resolved}</span>
              </div>
              <p>Resolved</p>
            </div>
            <div className="stat-item">
              <div className="stat-circle">
                <span>{stats.inProgress}</span>
              </div>
              <p>In Progress</p>
            </div>
          </div>
        </div>

        <div className="profile-card profile-card-map">
          <h2>Your Location</h2>
          <div className="map-placeholder">
            <div className="map-pin"></div>
            <div className="map-lines">
              <div className="line"></div>
              <div className="line"></div>
              <div className="line"></div>
            </div>
            <span>{profileData.location}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;