import React from 'react';
import { Modal, Button } from 'react-bootstrap';
import '@fortawesome/fontawesome-free/css/all.min.css';
import "../Styles/ComplaintDetailsModal.css";
const ComplaintDetailsModal = ({ show, onHide, complaint }) => {
  if (!complaint) return null;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const statusBadge = (status) => {
    const statusClasses = {
      'Pending': 'badge-warning',
      'In Progress': 'badge-info',
      'Resolved': 'badge-success'
    };
    return <span className={`badgee ${statusClasses[status]}`}>{status}</span>;
  };

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>Complaint Details</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="complaint-details">
          <div className="detail-row">
            <span className="detail-label">Complaint ID:</span>
            <span className="detail-value">{complaint._id}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Title:</span>
            <span className="detail-value">{complaint.title}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Category:</span>
            <span className="detail-value">{complaint.category}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Status:</span>
            <span className="detail-value">{statusBadge(complaint.status)}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Submitted:</span>
            <span className="detail-value">{formatDate(complaint.createdAt)}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Last Updated:</span>
            <span className="detail-value">{formatDate(complaint.updatedAt)}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Location:</span>
            <span className="detail-value">{complaint.location}</span>
          </div>
          <div className="detail-row full-width">
            <span className="detail-label">Description:</span>
            <div className="detail-value description-text">
              {complaint.description}
            </div>
          </div>
          
          {complaint.files?.length > 0 && (
            <div className="detail-row full-width">
              <span className="detail-label">Attachments:</span>
              <div className="attachments-grid">
                {complaint.files.map((file, index) => (
                  <div key={index} className="attachment-item">
                    {file.match(/\.(jpeg|jpg|gif|png)$/) ? (
                      <img  src={file} alt={`Attachment ${index + 1}`} className="attachment-image" />
                    ) : (
                      <div className="attachment-file">
                        <i className="fas fa-file-alt"></i>
                        <span>Attachment {index + 1}</span>
                      </div>
                    )}
                    <a href={file} target="_blank" rel="noopener noreferrer" className="view-full">
                      View Full <i className="fas fa-external-link-alt"></i>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ComplaintDetailsModal;