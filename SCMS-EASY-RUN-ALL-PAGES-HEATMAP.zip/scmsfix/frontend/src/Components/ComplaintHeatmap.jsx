import React, { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet.heat';
import '../Styles/ComplaintHeatmap.css';

const DEFAULT_CENTER = [11.0168, 76.9558]; // Tamil Nadu fallback (Coimbatore)

const ComplaintHeatmap = ({ complaints = [], compact = false }) => {
  const mapRef = useRef(null);
  const mapInstance = useRef(null);
  const heatLayerRef = useRef(null);
  const markersRef = useRef([]);
  const [points, setPoints] = useState([]);
  const [geocoding, setGeocoding] = useState(false);
  const [geocodeMessage, setGeocodeMessage] = useState('');

  const validComplaints = useMemo(() => complaints.filter(Boolean), [complaints]);

  useEffect(() => {
    let cancelled = false;

    const loadPoints = async () => {
      const direct = validComplaints
        .map((c) => {
          const lat = Number(c?.coordinates?.lat ?? c?.coordinates?.latitude);
          const lng = Number(c?.coordinates?.lng ?? c?.coordinates?.longitude);
          return Number.isFinite(lat) && Number.isFinite(lng)
            ? { lat, lng, complaint: c }
            : null;
        })
        .filter(Boolean);

      const missing = validComplaints.filter((c) => {
        const lat = Number(c?.coordinates?.lat ?? c?.coordinates?.latitude);
        const lng = Number(c?.coordinates?.lng ?? c?.coordinates?.longitude);
        return !(Number.isFinite(lat) && Number.isFinite(lng));
      });

      if (!missing.length) {
        if (!cancelled) setPoints(direct);
        return;
      }

      setGeocoding(true);
      setGeocodeMessage(`Finding map coordinates for ${missing.length} complaint${missing.length === 1 ? '' : 's'}...`);

      const cache = new Map();
      try {
        for (const complaint of missing) {
          if (cancelled) return;
          const location = String(complaint.location || '').trim();
          if (!location) continue;

          const key = location.toLowerCase();
          let coords = cache.get(key);
          if (!coords) {
            try {
              const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${encodeURIComponent(location + ', India')}`;
              const response = await fetch(url, { headers: { Accept: 'application/json' } });
              const results = await response.json();
              if (results?.[0]) {
                coords = { lat: Number(results[0].lat), lng: Number(results[0].lon) };
                cache.set(key, coords);
              }
            } catch (error) {
              console.warn('Geocoding failed for:', location, error);
            }
            await new Promise((resolve) => setTimeout(resolve, 1100));
          }

          if (coords && Number.isFinite(coords.lat) && Number.isFinite(coords.lng)) {
            direct.push({ ...coords, complaint });
          }
        }
      } finally {
        if (!cancelled) {
          setPoints(direct);
          setGeocoding(false);
          setGeocodeMessage(direct.length ? `${direct.length} complaint location${direct.length === 1 ? '' : 's'} mapped.` : 'No geographic coordinates available yet.');
        }
      }
    };

    loadPoints();
    return () => { cancelled = true; };
  }, [validComplaints]);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    const map = L.map(mapRef.current, { zoomControl: true, scrollWheelZoom: true }).setView(DEFAULT_CENTER, 7);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapInstance.current;
    if (!map) return;

    if (heatLayerRef.current) {
      map.removeLayer(heatLayerRef.current);
      heatLayerRef.current = null;
    }
    markersRef.current.forEach((marker) => map.removeLayer(marker));
    markersRef.current = [];

    if (!points.length) {
      map.setView(DEFAULT_CENTER, 7);
      return;
    }

    const grouped = new Map();
    points.forEach(({ lat, lng, complaint }) => {
      const key = `${lat.toFixed(5)},${lng.toFixed(5)}`;
      const current = grouped.get(key) || { lat, lng, count: 0, complaints: [] };
      current.count += 1;
      current.complaints.push(complaint);
      grouped.set(key, current);
    });

    const groups = Array.from(grouped.values());
    const maxCount = Math.max(...groups.map((g) => g.count), 1);
    const heatPoints = groups.map((g) => [g.lat, g.lng, Math.min(1, 0.25 + g.count / maxCount * 0.75)]);

    heatLayerRef.current = L.heatLayer(heatPoints, {
      radius: compact ? 28 : 38,
      blur: compact ? 20 : 25,
      maxZoom: 12,
      max: 1,
      minOpacity: 0.35,
      gradient: { 0.2: '#00b894', 0.45: '#fdcb6e', 0.7: '#e17055', 1: '#d63031' }
    }).addTo(map);

    groups.forEach((group) => {
      const marker = L.circleMarker([group.lat, group.lng], {
        radius: compact ? 5 : 7,
        weight: 2,
        color: '#ffffff',
        fillColor: '#d63031',
        fillOpacity: 0.9
      }).addTo(map);
      const names = group.complaints.slice(0, 8).map((c) => `<li>${escapeHtml(c.title || 'Complaint')} — ${escapeHtml(c.status || 'Pending')}</li>`).join('');
      marker.bindPopup(`<strong>${group.count} complaint${group.count === 1 ? '' : 's'}</strong><ul class="scms-popup-list">${names}</ul>`);
      markersRef.current.push(marker);
    });

    const bounds = L.latLngBounds(groups.map((g) => [g.lat, g.lng]));
    if (groups.length === 1) map.setView(bounds.getCenter(), compact ? 10 : 13);
    else map.fitBounds(bounds.pad(0.2), { maxZoom: compact ? 11 : 13 });

    setTimeout(() => map.invalidateSize(), 100);
  }, [points, compact]);

  return (
    <div className={`scms-heatmap-wrapper ${compact ? 'compact' : ''}`}>
      <div ref={mapRef} className="scms-heatmap-map" />
      <div className="scms-heatmap-overlay">
        <span><i className="hm-low" /> Low</span>
        <span><i className="hm-medium" /> Medium</span>
        <span><i className="hm-high" /> High</span>
      </div>
      {geocoding && <div className="scms-heatmap-status">{geocodeMessage}</div>}
      {!geocoding && !points.length && <div className="scms-heatmap-empty">{geocodeMessage || 'No complaint locations available yet.'}</div>}
    </div>
  );
};

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

export default ComplaintHeatmap;
