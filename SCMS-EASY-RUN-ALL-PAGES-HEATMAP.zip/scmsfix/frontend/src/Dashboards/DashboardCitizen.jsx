import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Pie, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
import '../Styles/DashboardCitizen.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import ComplaintFormModal from '../Components/ComplaintFormModal';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button } from 'react-bootstrap';
import styled from 'styled-components';
import "../Styles/Logoutbtn.css";

  


// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);



// Helper functions (place these before your component)
const getStatusColor = (status, isLight = false) => {
  const colors = {
    'Pending': isLight ? '#FEF3C7' : '#F59E0B',
    'In Progress': isLight ? '#DBEAFE' : '#3B82F6',
    'Resolved': isLight ? '#D1FAE5' : '#10B981'
  };
  return colors[status] || '#6B7280';
};
const formatDate = (dateString) => new Date(dateString).toLocaleDateString('en-US', { 
  year: 'numeric', 
  month: 'short', 
  day: 'numeric' 
});

const formatDateTime = (dateString) => new Date(dateString).toLocaleString('en-US', { 
  month: 'short', 
  day: 'numeric', 
  hour: '2-digit', 
  minute: '2-digit' 
});




const DEMO_CITIZEN_COMPLAINTS = [
  { _id: 'demo-c1', title: 'Road potholes', description: 'Potholes near the main road.', category: 'Road Issues (e.g., potholes)', location: 'Chennai', status: 'Pending', date: new Date().toISOString() },
  { _id: 'demo-c2', title: 'Garbage collection delay', description: 'Bins are overflowing.', category: 'Waste Management', location: 'Chennai', status: 'In Progress', date: new Date().toISOString() },
  { _id: 'demo-c3', title: 'Streetlight issue', description: 'Streetlight is not working.', category: 'Streetlight / Electrical', location: 'Chennai', status: 'Resolved', date: new Date().toISOString() }
];

const DashboardCitizen = () => {
  const [show, setShow] = useState(false);
  const [user, setUser] = useState({
    name: '',
    role: 'Citizen',
    complaints: 0,
    pending: 0,
    resolved: 0,
    inProgress: 0
  });
  const [complaints, setComplaints] = useState(() => new URLSearchParams(window.location.search).get('demo') === '1' ? DEMO_CITIZEN_COMPLAINTS : []);
  const [isLoading, setIsLoading] = useState(true);
const [notifications, setNotifications] = useState([]);
const [showNotificationPanel, setShowNotificationPanel] = useState(false);
const [selectedComplaint, setSelectedComplaint] = useState(null);
const [showComplaintModal, setShowComplaintModal] = useState(false);
const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
const panelRef = useRef(null);
// Add this state near your other state declarations
const [searchQuery, setSearchQuery] = useState('');
const [filteredComplaints, setFilteredComplaints] = useState([]);
const complaintsSectionRef = useRef(null);
// Add this useEffect to filter complaints when searchQuery or complaints change
useEffect(() => {
  if (searchQuery.trim() === '') {
    setFilteredComplaints(complaints);
  } else {
    const filtered = complaints.filter(complaint => 
      complaint.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      complaint.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      complaint._id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      complaint.status.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredComplaints(filtered);
    //  if (searchQuery && complaintsSectionRef.current) {
    //   complaintsSectionRef.current.scrollIntoView({ 
    //     behavior: 'smooth',
    //     block: 'start'
    //   });
    // }
  }
}, [searchQuery, complaints]);





  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userData = JSON.parse(localStorage.getItem('user'));
        console.log(userData);
        if (userData) {
          setUser(prev => ({
            ...prev,
            name: userData.fullName || 'User'
          }));
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);


 const fetchNotifications = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user')) || { id: 'demo-citizen-001' };
      const response = await fetch(`/api/complaints/notifications/${user.id}`);
      const data = await response.json();
      setNotifications(data);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };



useEffect(() => {
 
  fetchNotifications();
}, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (panelRef.current && !panelRef.current.contains(event.target)) {
        setShowComplaintModal(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleOpenComplaintDetails = async (complaintId) => {
  try {
    console.log(complaintId);
    const response = await fetch(`/api/complaints/${complaintId}`);
    const data = await response.json();

    if (response.ok) {
      setSelectedComplaint(data);
      setShowComplaintModal(true);
      
      await fetch(`/api/complaints/${complaintId}/mark-seen`, {
        method: 'PATCH'
      });

    


     
  fetchNotifications();

    } else {
      console.error(data.message);
    }
  } catch (error) {
    console.error('Failed to fetch complaint details:', error);
  }
};

  const handleMarkAllAsRead = async () => {
  try {
    const user = JSON.parse(localStorage.getItem('user'));

    const response = await fetch(`/api/complaints/notifications/mark-all-seen/${user.id}`, {
      method: 'PATCH',
    });

    if (response.ok) {
      await fetchNotifications(); // Refresh to get updated data
    } else {
      console.error('Failed to mark all as read');
    }
  } catch (err) {
    console.error('Error in mark all as read:', err);
  }
};


  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        setIsLoading(true);
        const user = JSON.parse(localStorage.getItem('user'));
        const userId = user?.id;

        const response = await fetch(`/api/complaints/citizen/${userId}`);
        const data = await response.json();

        if (response.ok) {
          const isDemo = new URLSearchParams(window.location.search).get('demo') === '1';
          if (!isDemo || data.length) setComplaints(data);

          // Calculate complaint status counts
          const pending = data.filter(c => c.status === 'Pending').length;
          const resolved = data.filter(c => c.status === 'Resolved').length;
          const inProgress = data.filter(c => c.status === 'In Progress').length;

          setUser(prev => ({
            ...prev,
            complaints: data.length,
            pending,
            resolved,
            inProgress
          }));
        } else {
          console.error(data.message);
        }
      } catch (error) {
        console.error('Error fetching complaints:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchComplaints();
  }, []);

  // Chart data
  const pieData = {
    labels: ['Pending', 'Resolved', 'In Progress'],
    datasets: [
      {
        data: [user.pending, user.resolved, user.inProgress],
        backgroundColor: [
          '#FFBF00', // Yellow for pending
          '#4CAF50', // Green for resolved
          '#2A5BD7'  // Blue for in progress
        ],
        borderWidth: 0,
      },
    ],
  };



  

  // Group complaints by month for bar chart
  const complaintsByMonth = complaints.reduce((acc, complaint) => {
    const month = new Date(complaint.createdAt).getMonth();
    acc[month] = (acc[month] || 0) + 1;
    return acc;
  }, {});

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const barData = {
    labels: monthNames,
    datasets: [
      {
        label: 'Complaints Submitted',
        data: monthNames.map((_, index) => complaintsByMonth[index] || 0),
        backgroundColor: '#2A5BD7',
        borderRadius: 4,
      },
    ],
  };

  const statusBadge = (status) => {
    const statusClasses = {
      'Pending': 'badge-warning',
      'In Progress': 'badge-info',
      'Resolved': 'badge-success'
    };
    return <span className={`badgee ${statusClasses[status]}`}>{status}</span>;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };





  
  const handleNewComplaintSubmit = async (complaintData) => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const formData = new FormData();
      
      // Append all complaint data to formData
      Object.keys(complaintData).forEach(key => {
        if (key === 'files') {
          Array.from(complaintData.files).forEach(file => {
            formData.append('files', file);
          });
        } else {
          formData.append(key, complaintData[key]);
        }
      });
      
      formData.append('userId', user.id);

      const response = await fetch('/api/complaints', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (response.ok) {
        // Refresh complaints after successful submission
        const updatedResponse = await fetch(`/api/complaints/citizen/${user.id}`);
        const updatedData = await updatedResponse.json();
        
        if (updatedResponse.ok) {
          setComplaints(updatedData);
          
          // Update counts
          const pending = updatedData.filter(c => c.status === 'Pending').length;
          const resolved = updatedData.filter(c => c.status === 'Resolved').length;
          const inProgress = updatedData.filter(c => c.status === 'In Progress').length;

          setUser(prev => ({
            ...prev,
            complaints: updatedData.length,
            pending,
            resolved,
            inProgress
          }));
        }
        
        handleClose();
      } else {
        console.error(data.message);
        // Handle error (show toast/message)
      }
    } catch (error) {
      console.error('Error submitting complaint:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="dashboard-citizen loading">
        <div className="spinner-container">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-citizen">
      {/* Complaint Form Modal */}
      <ComplaintFormModal 
        show={show}
        onHide={handleClose}
        onSubmit={handleNewComplaintSubmit}
      />

      {/* Header */}
      <header className="dashboard-header">
        <div className="header-content">
          <div className="user-greeting">
            <h1>Welcome, {user.name}!</h1>
            <p className="user-role">Role: {user.role}</p>
          </div>
          
          <div className="header-center">
         <div className="quick-search">
  <i className="fas fa-search"></i>
  <input 
    type="text" 
    placeholder="Search complaints by title, ID, or status..." 
    className="search-input"
    value={searchQuery}
    onChange={(e) => setSearchQuery(e.target.value)}
    onKeyDown={(e) => {
      if (e.key === 'Enter' && searchQuery && complaintsSectionRef.current) {
        complaintsSectionRef.current.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
    }}
    aria-label="Search complaints"
  />
  {searchQuery && (
    <button 
      className="search-clear-btn"
      onClick={() => {
        setSearchQuery('');
        if (complaintsSectionRef.current) {
          complaintsSectionRef.current.scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
          });
        }
      }}
      aria-label="Clear search"
    >
      <i className="fas fa-times"></i>
    </button>
  )}
</div>

            <div className="date-display">
              <i className="fas fa-calendar-alt"></i>
              <span>{new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                month: 'long', 
                day: 'numeric',
                year: 'numeric'
              })}</span>
            </div>
          </div>
          
          <div className="header-actions">
          <button className="btn btn-notification" onClick={() => setShowNotificationPanel(true)}>
  <i className="fas fa-bell"></i>
  {notifications.length > 0 && (
    <span className="notification-count">{notifications.length}</span>
  )}
</button>
 <Link to="/profile">
            <div className="user-avatarr">
              <i className="fas fa-user"></i>
            </div>
            </Link>
          </div>
        </div>
        <div className="mobile-header-container">
  {/* Top Bar - User Info and Actions */}
  <div className="mobile-top-bar">
    <div className="mobile-user-info">
      <Link to="/profile" className="mobile-avatar-link">
        <div className="mobile-user-avatar">
          {user.photo ? (
            <img src={user.photo} alt={user.name} />
          ) : (
            <i className="fas fa-user-circle"></i>
          )}
        </div>
      </Link>
      <div className="mobile-user-details">
        <h1 className="mobile-greeting">Hi, {user.name.split(' ')[0]}!</h1>
        <p className="mobile-user-role">{user.role}</p>
      </div>
    </div>
    
    <div className="mobile-actions">
      <button 
        className="mobile-notification-btn"
        onClick={() => setShowNotificationPanel(true)}
      >
        <i className="fas fa-bell"></i>
        {notifications.length > 0 && (
          <span className="mobile-notification-badge">{notifications.length}</span>
        )}
      </button>
    </div>
  </div>

  {/* Date Display */}
  <div className="mobile-date-display">
    <i className="fas fa-calendar-day"></i>
    <span>
      {new Date().toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric'
      })}
    </span>
  </div>

  {/* Search Bar */}
  <div className="mobile-search-container">
    <div className="mobile-search-bar">
      <i className="fas fa-search mobile-search-icon"></i>
      <input
        type="text"
        placeholder="Search complaints..."
        className="mobile-search-input"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && searchQuery && complaintsSectionRef.current) {
            complaintsSectionRef.current.scrollIntoView({ 
              behavior: 'smooth',
              block: 'start'
            });
          }
        }}
        aria-label="Search complaints"
      />
      {searchQuery && (
        <button 
          className="mobile-search-clear"
          onClick={() => {
            setSearchQuery('');
            if (complaintsSectionRef.current) {
              complaintsSectionRef.current.scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
              });
            }
          }}
          aria-label="Clear search"
        >
          <i className="fas fa-times"></i>
        </button>
      )}
    </div>
  </div>
</div>
      </header>

      {/* Quick Actions */}
      <section className="quick-actions">
        <h2 className="section-title">Quick Actions</h2>

{/* <button className="logout-button" onClick={() => setShowLogoutModal(true)}>
  <span className="nav-icon">🚪</span>
  Logout
</button> */}

<button className="BttnLogout"  onClick={() => setShowLogoutModal(true)}>
  
  <div className="sign"><svg viewBox="0 0 512 512"><path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path></svg></div>
  
  <div className="texxt">Logout</div>
</button>





{showLogoutModal && (
  <div className="authflow-logout-overlay" onClick={() => setShowLogoutModal(false)}>
    <div className="authflow-logout-dialog" onClick={e => e.stopPropagation()}>
      <div className="authflow-logout-icon">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 3V6M12 18V21M5 12H3M21 12H16M6.2 7.8L4 5.5M17.8 7.8L20 5.5M6.2 16.2L4 18.5M17.8 16.2L20 18.5M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h3 className="authflow-logout-title">Ready to leave?</h3>
      <p className="authflow-logout-message">Are you sure you want to log out of your account?</p>
      <div className="authflow-logout-actions">
        <button
          className="authflow-logout-secondary"
          onClick={() => setShowLogoutModal(false)}
        >
          Stay logged in
        </button>
        <button
          className="authflow-logout-primary"
          onClick={() => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            setShowLogoutModal(false);
            window.location.href = '/login';
          }}
        >
          Log out
        </button>
      </div>
    </div>
  </div>
)}

<StyledWrapper>
      <button  onClick={handleShow} className="animated-button">
        <svg xmlns="http://www.w3.org/2000/svg" className="arr-2" viewBox="0 0 24 24">
          <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
        </svg>
        <span className="text"><i className="fas fa-plus-circle"></i> <span className='word'> New Complaint </span></span>
        <span className="circle" />
        <svg xmlns="http://www.w3.org/2000/svg" className="arr-1" viewBox="0 0 24 24">
          <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
        </svg>
      </button>
    </StyledWrapper>

        <div className="action-grid">
          <button onClick={handleShow} className="action-card primary">
            <i className="fas fa-plus-circle"></i>
            <h3>Submit New Complaint</h3>
            <p>Report a new municipal issue</p>
          </button>
          <Link to="/complaint-history" className="action-card">
            <i className="fas fa-history"></i>
            <h3>View Complaint History</h3>
            <p>See all your past complaints</p>
          </Link>
          <Link to="/track-complaint" className="action-card">
            <i className="fas fa-map-marked-alt"></i>
            <h3>Track Complaint Status</h3>
            <p>Check progress of your reports</p>
          </Link>
          <Link to="/profile" className="action-card">
            <i className="fas fa-user-edit"></i>
            <h3>My Profile</h3>
            <p>Update your information</p>
          </Link>
        </div>
      </section>

      {/* Stats and Charts */}
      <section className="dashboard-stats">
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Total Complaints</h3>
            <div className="stat-value">{user.complaints}</div>
            <div className="stat-trend">
              {user.complaints > 0 ? (
                <i className="fas fa-arrow-up"></i>
              ) : (
                <i className="fas fa-minus"></i>
              )}
              {user.complaints > 0 ? ' Active' : ' No complaints yet'}
            </div>
          </div>
          <div className="stat-card">
            <h3>Pending Complaints</h3>
            <div className="stat-value">{user.pending}</div>
            <div className="stat-trend">
              {user.pending > 0 ? (
                <i className="fas fa-exclamation-circle"></i>
              ) : (
                <i className="fas fa-check-circle"></i>
              )}
              {user.pending > 0 ? ' Needs attention' : ' All clear'}
            </div>
          </div>
          <div className="stat-card">
            <h3>Resolved Complaints</h3>
            <div className="stat-value">{user.resolved}</div>
            <div className="stat-trend">
              {user.resolved > 0 ? (
                <i className="fas fa-check"></i>
              ) : (
                <i className="fas fa-info-circle"></i>
              )}
              {user.resolved > 0 ? ` ${Math.round((user.resolved / user.complaints) * 100)}% resolved` : ' None yet'}
            </div>
          </div>
        </div>

        {user.complaints > 0 && (
          <div className="charts-container">
            <div className="chart-card">
              <h3>Complaint Status</h3>
              <div className="chart-wrapper">
                <Pie data={pieData} options={{ responsive: true, maintainAspectRatio: false }} />
              </div>
            </div>
            <div className="chart-card">
              <h3>Monthly Activity</h3>
              <div className="chart-wrapper">
                <Bar data={barData} options={{ responsive: true, maintainAspectRatio: false }} />
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Recent Activity */}
      <section className="recent-activity"  ref={complaintsSectionRef}>
        <div className="section-header">
          <h2 className="section-title">Latest Complaint Activity</h2>
          <Link to="/complaint-history" className="view-all">View All</Link>
        </div>
        
        {filteredComplaints.length > 0 ? (
  <div className="complaints-tabl">
    <div className="table-header">
      <div className="header-cell">Complaint ID</div>
      <div className="header-cell">Title</div>
      <div className="header-cell">Status</div>
      <div className="header-cell">Date</div>
    </div>
    
    {filteredComplaints.slice(0, 5).map((complaint) => (
      <div className="table-row" key={complaint._id}>
        <div className="table-cell">{complaint._id.substring(0, 8)}...</div>
        <div className="table-cell">{complaint.title}</div>
        <div className="table-cell">{statusBadge(complaint.status)}</div>
        <div className="table-cell">{formatDate(complaint.createdAt)}</div>
      </div>
    ))}  
  </div>
) : searchQuery ? (
  <div className="no-results">
    <i className="fas fa-search"></i>
    <p>No complaints found matching "{searchQuery}"</p>
    <button 
      className="btn btn-link"
      onClick={() => setSearchQuery('')}
    >
      Clear search
    </button>
  </div>
) : (
  <div className="no-complaints">
    <i className="fas fa-inbox"></i>
    <p>You haven't submitted any complaints yet</p>
    <button onClick={handleShow} className="btn btn-primary">
      Submit Your First Complaint
    </button>
  </div>
)}

      </section>
      {showNotificationPanel && (
  //  ref={panelRef}
  <div className="notifly-panel-container"  > 
    <div className="notifly-header-wrapper">
      <div className="notifly-header-main">
        <div className="notifly-count-indicator">
          {notifications.length}
        </div>
        <h3 className="notifly-title-text">Updates</h3>
      </div>
      <div className="notifly-header-actions">
        <button className="notifly-mark-read-btn" onClick={handleMarkAllAsRead} >Mark all as read</button>
        <button 
          className="notifly-close-btn" 
          onClick={() => setShowNotificationPanel(false)}
          aria-label="Close notifications"
        >
          <span className="notifly-close-icon"></span>
        </button>
      </div>
    </div>
    
    <div className="notifly-items-container">
      {notifications.length === 0 ? (
        <div className="notifly-empty-state">
          <div className="notifly-empty-icon">📭</div>
          <h4 className="notifly-empty-title">All caught up!</h4>
          <p className="notifly-empty-message">No new notifications</p>
        </div>
      ) : (
        notifications.map((note, index) => {
          // Convert status to proper class name format
          const statusClass = `notifly-status-${note.status.toLowerCase().replace(' ', '-')}`;
          return (
            <div 
              className={`notifly-item-card ${statusClass} ${note.seen ? '' : 'notifly-unread-item'}`} 
              key={note.id || index}
            >
              <div className="notifly-unread-dot"></div>
              <div className="notifly-content-wrapper">
                <div className="notifly-item-header">
                  <h5 className="notifly-item-title">{note.title}</h5>
                  <span className="notifly-status-badge">{note.status}</span>
                </div>
                <p className="notifly-message-text">{note.message}</p>
                <div className="notifly-item-footer">
                  <span className="notifly-timestamp">
                      {new Date(note.timestamp).toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  })}

                  </span>
                  <button className="notifly-action-button" onClick={() => handleOpenComplaintDetails(note.complaintId)}>Details</button>
                </div>
              </div>
            </div>
          );
        })
      )}
    </div>
  </div>
)}


{/* kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk0 */}



{showComplaintModal && selectedComplaint && (
  <div className="cm-overlay" onClick={() => setShowComplaintModal(false)}>
    <div className="cm-card">
      {/* Header with gradient */}
      <div className="cm-header" style={{ 
        background: `linear-gradient(135deg, ${getStatusColor(selectedComplaint.status, true)} 0%, ${getStatusColor(selectedComplaint.status, false)} 100%)`
      }}>
        <div className="cm-header-content">
          <div className="cm-title-wrapper">
            <span className="cm-category-tag">{selectedComplaint.category}</span>
            <h2 className="cm-main-title">{selectedComplaint.title}</h2>
          </div>
          <button 
            className="cm-close-btn"
            onClick={() => setShowComplaintModal(false)}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              <path d="M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="cm-body">
        {/* Status ribbon */}
        <div className="cm-status-ribbon" style={{ backgroundColor: getStatusColor(selectedComplaint.status, false) }}>
          <span className="cm-status-text">{selectedComplaint.status}</span>
          <div className="cm-ribbon-tail"></div>
        </div>

        {/* Location and dates */}
        <div className="cm-meta-info">
          <div className="cm-location">
            <svg className="cm-location-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 12.5C13.6569 12.5 15 11.1569 15 9.5C15 7.84315 13.6569 6.5 12 6.5C10.3431 6.5 9 7.84315 9 9.5C9 11.1569 10.3431 12.5 12 12.5Z" stroke="#4F46E5" strokeWidth="2"/>
              <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" stroke="#4F46E5" strokeWidth="2"/>
            </svg>
            <span className="cm-location-text">{selectedComplaint.location}</span>
          </div>
          <div className="cm-dates">
            <span className="cm-date-reported">Reported: {formatDate(selectedComplaint.createdAt)}</span>
            <span className="cm-date-updated">Updated: {formatDate(selectedComplaint.updatedAt)}</span>
          </div>
        </div>

        {/* Description */}
        <div className="cm-description">
          <h3 className="cm-section-title">DESCRIPTION</h3>
          <p className="cm-description-text">{selectedComplaint.description}</p>
        </div>

        {/* Updates timeline */}
        <div className="cm-updates">
          <h3 className="cm-section-title">UPDATES</h3>
          <div className="cm-timeline">
            {selectedComplaint.remarks.map((remark, i) => (
              <div key={i} className={`cm-timeline-item ${remark.seen ? '' : 'cm-unseen'}`}>
                <div className="cm-timeline-marker"></div>
                <div className="cm-timeline-content">
                  <p className="cm-update-text">{remark.message}</p>
                  <span className="cm-update-date">{formatDateTime(remark.timestamp)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reported by */}
        <div className="cm-reporter">
          <div className="cm-reporter-avatar">
            {selectedComplaint.userId.fullName.charAt(0).toUpperCase()}
          </div>
          <div className="cm-reporter-info">
            <h4 className="cm-reporter-title">Reported By</h4>
            <p className="cm-reporter-name">{selectedComplaint.userId.fullName}</p>
            <p className="cm-reporter-email">{selectedComplaint.userId.email}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
)} 
    </div>
  );
};



const StyledWrapper = styled.div`
  .animated-button {
    position: absolute;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 16px 36px;
    border: 4px solid;
    border-color: transparent;
    font-size: 16px;
    background-color: ;
    border-radius: 100px;
    font-weight: 600;
    color: #1f387e;
    box-shadow: 0 0 0 2px #ffffff;
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
    right:30px;
    top:180px;
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: #1f387e;
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: #c5e5e4;
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button:hover {
    box-shadow: 0 0 0 12px transparent;
    color: #212121;
    border-radius: 100px;
  }

  .animated-button:hover .arr-1 {
    right: -25%;
  }

  .animated-button:hover .arr-2 {
    left: 16px;
  }

  .animated-button:hover .text {
    transform: translateX(12px);
  }

  .animated-button:hover svg {
    fill: #1f387e;
  }

  .animated-button:active {
    scale: 0.95;
  }

  .animated-button:hover .circle {
    width: 220px;
    height: 220px;
    opacity: 1;
  }`;





export default DashboardCitizen;