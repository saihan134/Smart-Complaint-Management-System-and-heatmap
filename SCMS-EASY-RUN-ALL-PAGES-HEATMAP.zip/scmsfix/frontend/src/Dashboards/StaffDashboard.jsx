import { useState, useEffect } from 'react';
import axios from 'axios';
import '../Styles/StaffDashboard.css';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import Papa from 'papaparse';
import { useNavigate } from 'react-router-dom';
import {
  FiHome,         // Dashboard
  FiAlertCircle,  // My Complaints
  FiBarChart2,    // Statistics
  FiUser,         // Profile
  FiLogOut ,     // Logout
  FiEye
} from 'react-icons/fi';


const DEMO_STAFF_COMPLAINTS = [
  { _id: 'demo-s1', title: 'Pothole repair', description: 'Repair required urgently.', category: 'Road Issues (e.g., potholes)', location: 'Chennai', status: 'Pending', date: new Date().toISOString() },
  { _id: 'demo-s2', title: 'Waste pickup', description: 'Collection requested.', category: 'Waste Management', location: 'Chennai', status: 'In Progress', date: new Date().toISOString() },
  { _id: 'demo-s3', title: 'Streetlight replacement', description: 'Lamp replacement completed.', category: 'Streetlight / Electrical', location: 'Chennai', status: 'Resolved', date: new Date().toISOString() }
];

const StaffDashboard = () => {
   const navigate = useNavigate();
const [staffAccountDate, setStaffAccountDate] = useState();
const [staffData, setStaffData] = useState({
  fullName: '',
  role: '',
  location: '',
  email: ''
});

useEffect(() => {
  const fetchStaffData = async () => {
    try {
      const userData = JSON.parse(localStorage.getItem('user'));
      console.log("Fetched from localStorage:", userData);

      if (userData) {
        setStaffData({
          fullName: userData.fullName || 'Unknown',
          role: userData.role || 'Staff',
          location: userData.location || 'Not specified',
          email: userData.email || 'Not available'
        });
      }
      setStaffAccountDate(userData.createdAt);
     
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  fetchStaffData();
}, []);

  



  
  const [complaints, setComplaints] = useState(() => new URLSearchParams(window.location.search).get('demo') === '1' ? DEMO_STAFF_COMPLAINTS : []);
  const [filteredComplaints, setFilteredComplaints] = useState([]);
  const [showReportModal, setShowReportModal] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    inProgress: 0,
    resolved: 0,
    urgent: 0
  });
  const [statistics, setStatistics] = useState({
  total: 0,
  resolved: 0,
  inProgress: 0,
  pending: 0,
  resolutionRate: 0,
  rating: 0,
  avgResolutionTime: 0
});
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [statusUpdate, setStatusUpdate] = useState('');
  const [remarks, setRemarks] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
const [mockComplaints, setMockComplaints] = useState([]);
const [unseenComplaints, setUnseenComplaints] = useState([]);
const [showUnseenModal, setShowUnseenModal] = useState(false);
const [resolutionData, setResolutionData] = useState([]);
const [showLogoutModal, setShowLogoutModal] = useState(false);





useEffect(() => {
  const calculateResolutionTime = () => {
    const categoryMap = {};

    filteredComplaints.forEach(complaint => {
      if (complaint.status === 'Resolved') {
        const category = complaint.category;
        const created = new Date(complaint.createdAt);
        const updated = new Date(complaint.updatedAt);
        const days = Math.ceil((updated - created) / (1000 * 60 * 60 * 24)); // difference in days

        if (!categoryMap[category]) {
          categoryMap[category] = [];
        }
        categoryMap[category].push(days);
      }
    });

    const result = Object.entries(categoryMap).map(([category, daysArray]) => {
      const total = daysArray.reduce((acc, d) => acc + d, 0);
      const avg = total / daysArray.length;
      return { category, avgDays: avg.toFixed(1) };
    });

    setResolutionData(result);
  };

  calculateResolutionTime();
}, [filteredComplaints]);



useEffect(() => {
  const fetchComplaints = async () => {
    try {
      const res = await fetch('/api/complaints');
      const allData = await res.json();

      const staffComplaints = allData.filter(
        c => c.location === staffData.location
      );

      setFilteredComplaints(staffComplaints);

      // Dynamic statistics
      const total = staffComplaints.length;
      const resolved = staffComplaints.filter(c => c.status === 'Resolved').length;
      const inProgress = staffComplaints.filter(c => c.status === 'In Progress').length;
      const pending = total - resolved - inProgress;

      const resolutionTimes = staffComplaints
        .filter(c => c.status === 'Resolved')
        .map(c => {
          const created = new Date(c.createdAt);
          const updated = new Date(c.updatedAt);
          return (updated - created) / (1000 * 60 * 60 * 24); // in days
        });

      const avgResolutionTime = resolutionTimes.length
        ? (resolutionTimes.reduce((a, b) => a + b, 0) / resolutionTimes.length).toFixed(1)
        : '0';

      const resolutionRate = total ? Math.round((resolved / total) * 100) : 0;

      setStatistics({
        total,
        resolved,
        inProgress,
        pending,
        resolutionRate,
        avgResolutionTime,
        // You can hardcode rating or fetch separately if implemented
        rating: 0 
      });
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  fetchComplaints();
}, [staffData.location]);



  useEffect(() => {
    // Fetch staff complaints data
    const fetchData = async () => {
      try {

        const response = await fetch(`/api/complaints`);
        const data = await response.json();
        setMockComplaints(data);

       
        const staffLocationComplaints = data.filter(
          complaint => complaint.location === staffData.location
        );
        
        const isDemo = new URLSearchParams(window.location.search).get('demo') === '1';
        if (!isDemo || staffLocationComplaints.length) setComplaints(staffLocationComplaints);
        setFilteredComplaints(staffLocationComplaints);
        
        // Calculate stats
        const total = staffLocationComplaints.length;
        const inProgress = staffLocationComplaints.filter(c => c.status === 'In Progress').length;
        const resolved = staffLocationComplaints.filter(c => c.status === 'Resolved').length;
        const urgent = staffLocationComplaints.filter(c => 
          c.status !== 'Resolved' && 
          new Date(c.date) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        ).length;
        
        setStats({ total, inProgress, resolved, urgent });
        setIsLoading(false);
      } catch (err) {
        console.error('Error fetching data:', err);
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [staffData.location]);


useEffect(() => {
  const fetchUnseenComplaints = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const response = await fetch(`/api/complaints/unseen/${user.location}`);
      const data = await response.json();
      if (response.ok) {
        setUnseenComplaints(data);
      }
    } catch (error) {
      console.error('Error fetching unseen complaints:', error);
    }
  };

  fetchUnseenComplaints();
}, []);



  useEffect(() => {
    // Filter complaints based on search and filters
    let result = complaints;
    
    // Apply search filter
    if (searchTerm) {
      result = result.filter(complaint => 
        complaint.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        complaint.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply status filter
    if (filterStatus !== 'all') {
      result = result.filter(complaint => complaint.status === filterStatus);
    }
    
    // Apply category filter
    if (filterCategory !== 'all') {
      result = result.filter(complaint => complaint.category === filterCategory);
    }
    
    setFilteredComplaints(result);
  }, [searchTerm, filterStatus, filterCategory, complaints]);

 const handleStatusUpdate = async () => {
  if (!statusUpdate) return alert('Please select a new status.');

  try {
    const response = await fetch(`/api/complaints/${selectedComplaint._id}/update-status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        status: statusUpdate,
        remarkMessage: typeof remarks === 'string' && remarks.trim() !== '' ? remarks.trim() : null
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Failed to update status');
    }

    // Update local state with updated complaint from backend
    const updatedComplaints = complaints.map(complaint =>
      complaint._id === selectedComplaint._id ? result.complaint : complaint
    );

    setComplaints(updatedComplaints);
    setSelectedComplaint(result.complaint);

    // Recalculate stats
    const total = updatedComplaints.length;
    const inProgress = updatedComplaints.filter(c => c.status === 'In Progress').length;
    const resolved = updatedComplaints.filter(c => c.status === 'Resolved').length;
    const urgent = updatedComplaints.filter(c =>
      c.status !== 'Resolved' &&
      new Date(c.date) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    ).length;

    setStats({ total, inProgress, resolved, urgent });

    // Reset UI state
    setIsModalOpen(false);
    setStatusUpdate('');
    setRemarks('');

    alert('Complaint status updated successfully!');
  } catch (error) {
    console.error('Error updating status:', error);
    alert('Failed to update status. Please try again.');
  }
};

const handleComplaintClick = async (complaint) => {
  try {
    // Call the mark-seen API
    openComplaintDetails(complaint)
    await fetch(`/api/complaints/mark-seen/${complaint._id}`, {
      method: 'PUT'
    });

    // Open the modal or do something with the clicked complaint
    setSelectedComplaint(complaint);

    // Optionally update unseen complaints list
    setUnseenComplaints(prev => prev.filter(c => c._id !== complaint._id));
  } catch (error) {
    console.error('Error marking complaint as seen:', error);
  }
};



  const openComplaintDetails = (complaint) => {
    setSelectedComplaint(complaint);
    setStatusUpdate(complaint.status);
    setRemarks(complaint.remarks || '');
    setIsModalOpen(true);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Pending': return 'var(--warning)';
      case 'In Progress': return 'var(--primary)';
      case 'Resolved': return 'var(--secondary)';
      default: return 'var(--gray)';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'Road Issues': return '🚧';
      case 'Waste Management': return '🗑️'; 
      case 'Public Utilities': return '💡';
      default: return '📋';
    }
  };


// For modal open/close
const handleOpenReportModal = () => setShowReportModal(true);
const handleCloseReportModal = () => setShowReportModal(false);

// PDF Download
const downloadPDF = () => {
  const element = document.querySelector('.rm-table-wrapper'); // or use a ref

  if (!element) {
    console.error("Report table element not found.");
    return;
  }

  html2canvas(element, { scale: 2 })
    .then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('complaints_report.pdf');
    })
    .catch(err => {
      console.error('Error generating PDF:', err);
    });
};


// CSV Download
const downloadCSV = () => {
  const csvData = filteredComplaints.map(c => ({
    ID: c._id,
    Title: c.title,
    Category: c.category,
    Status: c.status,
    Location: c.location,
    Date: new Date(c.date).toLocaleDateString()
  }));
  const csv = Papa.unparse(csvData);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'complaints_report.csv';
  link.click();
};



  if (isLoading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  return (
    <div className="staff-dashboard">
      {/* Sidebar */}
      <div className="dashboard-sidebar">
        <div className="sidebar-header">
          <div className="staff-avatar" onClick={() => setActiveTab('profile')}>
            {staffData.fullName.charAt(0)}
          </div>
          <div className="staff-info">
            <h3>{staffData.fullName}</h3>
            <p>{staffData.role}</p>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <button 
            className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <span className="nav-icon"><FiHome className="nav-icon" /></span>
            <span className='navlink'>Dashboard</span>
            
          </button>
          <button 
            className={`nav-item ${activeTab === 'complaints' ? 'active' : ''}`}
            onClick={() => setActiveTab('complaints')}
          >
            <span className="nav-icon"><FiAlertCircle className="nav-icon" /></span>
            <span className='navlink'>My Complaints</span>
          </button>
          <button 
            className={`nav-item ${activeTab === 'stats' ? 'active' : ''}`}
            onClick={() => setActiveTab('stats')}
          >
            <span className="nav-icon"> <FiBarChart2 className="nav-icon" /></span>
            <span className='navlink'>Statistics</span>
          </button>
          <button 
            className={`nav-item ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            <span className="nav-icon"><FiUser className="nav-icon" /></span>
            <span className='navlink'>Profile</span>
          </button>
          <button className="logout-button mobile_logout" onClick={() => setShowLogoutModal(true)}>
  <span className="nav-icon"><FiLogOut className="nav-icon" /></span>
  <span className='navlink'>Logout</span>
</button>
        </nav>
        
        <div className="sidebar-footer">
          <button className="logout-button" onClick={() => setShowLogoutModal(true)}>
  <span className="nav-icon"><FiLogOut className="nav-icon" /></span>
  <span className='navlink'>Logout</span>
</button>

        </div>
      </div>

{/* -------------------------------- */}
{showLogoutModal && (
  <div className="authflow-logout-overlay" onClick={() => setShowLogoutModal(false)}>
    <div className="authflow-logout-dialog" onClick={e => e.stopPropagation()}>
      <div className="authflow-logout-icon">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 3V6M12 18V21M5 12H3M21 12H16M6.2 7.8L4 5.5M17.8 7.8L20 5.5M6.2 16.2L4 18.5M17.8 16.2L20 18.5M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h3 className="authflow-logout-title">Ready to leave?</h3>
      <p className="authflow-logout-message">Are you sure you want to log out of your account?</p>
      <div className="authflow-logout-actions">
        <button
          className="authflow-logout-secondary"
          onClick={() => setShowLogoutModal(false)}
        >
          Stay logged in
        </button>
        <button
          className="authflow-logout-primary"
          onClick={() => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            setShowLogoutModal(false);
            
            window.location.href = '/login';

          }}
        >
          Log out
        </button>
      </div>
    </div>
  </div>
)}



      
      
      {/* Main Content */}
      <div className="dashboard-main">
        {/* Header */}
        <header className="dashboard-header">
          <h1>
            {activeTab === 'dashboard' && 'Staff Dashboard'}
            {activeTab === 'complaints' && 'Complaint Management'}
            {activeTab === 'stats' && 'Statistics & Reports'}
            {activeTab === 'profile' && 'My Profile'}
          </h1>
          
          <div className="header-actions">
            <button 
              className="notification-button" 
              onClick={() => setShowUnseenModal(true)}
            >

              {unseenComplaints.length > 0 && (
             <span className="notification-badge">{unseenComplaints.length}</span>
              )}

  
              🔔
            </button>

            <div className="location-tag">
              📍 {staffData.location} 
            </div>
          </div>
        </header>
        
        {/* Dashboard Content */}
        <div className="dashboard-content">
          {activeTab === 'dashboard' && (
            <>
              {/* Stats Cards */}
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-icon">📝</div>
                  <div className="stat-info">
                    <h3>{stats.total}</h3>
                    <p>Total Complaints</p>
                  </div>
                  <div className="stat-arc" style={{ background: 'conic-gradient(var(--primary) 100%, var(--gray-light) 0%)' }}></div>
                </div>
                
                <div className="stat-card">
                  <div className="stat-icon">⏳</div>
                  <div className="stat-info">
                    <h3>{stats.inProgress}</h3>
                    <p>In Progress</p>
                  </div>
                  <div className="stat-arc" style={{ background: `conic-gradient(var(--primary) ${(stats.inProgress / stats.total) * 100}%, var(--gray-light) 0%)` }}></div>
                </div>
                
                <div className="stat-card">
                  <div className="stat-icon">✅</div>
                  <div className="stat-info">
                    <h3>{stats.resolved}</h3>
                    <p>Resolved</p>
                  </div>
                  <div className="stat-arc" style={{ background: `conic-gradient(var(--secondary) ${(stats.resolved / stats.total) * 100}%, var(--gray-light) 0%)` }}></div>
                </div>
                
                <div className="stat-card">
                  <div className="stat-icon">🔥</div>
                  <div className="stat-info">
                    <h3>{stats.urgent}</h3>
                    <p>Urgent</p>
                  </div>
                  <div className="stat-arc" style={{ background: `conic-gradient(var(--warning) ${(stats.urgent / stats.total) * 100}%, var(--gray-light) 0%)` }}></div>
                </div>
              </div>
              
              {/* Recent Activity */}
              <div className="recent-activity">
                <h2>Recent Activity</h2>
                <div className="activity-timeline">
                  {filteredComplaints.slice(0, 3).map(complaint => (
                    <div key={complaint._id} className="activity-item">
                      <div className="activity-icon">{getCategoryIcon(complaint.category)}</div>
                      <div className="activity-details">
                        <h4>{complaint.title}</h4>
                        <p>{complaint.category} • {new Date(complaint.date).toLocaleDateString()}</p>
                        <span className="activity-status" style={{ backgroundColor: getStatusColor(complaint.status) }}>
                          {complaint.status}
                        </span>
                      </div>
                      <button 
                        className="activity-action"
                        onClick={() => openComplaintDetails(complaint)}
                      >
                        View
                      </button>
                    </div>
                  ))}
                </div>
              </div>
{/* dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd */}



{showReportModal && (
  <div className="rm-overlay" onClick={handleCloseReportModal}>
    <div className="rm-container" onClick={e => e.stopPropagation()}>
      {/* Gradient Header */}
      <div className="rm-header" style={{
        background: 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)'
      }}>
        <div className="rm-header-content">
          <svg className="rm-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h2 className="rm-title">Complaint Analytics Report</h2>
        </div>
        <button 
          className="rm-close-btn"
          onClick={handleCloseReportModal}
          aria-label="Close report"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M18 6L6 18" stroke="white" strokeWidth="2" strokeLinecap="round"/>
            <path d="M6 6L18 18" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </button>
      </div>

      {/* Report Body */}
      <div className="rm-body" id="rm-table-container">
        <div className="rm-table-wrapper">
          <table className="rm-data-table">
            <thead className="rm-table-header">
              <tr>
                <th className="rm-th">ID</th>
                <th className="rm-th">Title</th>
                <th className="rm-th">Category</th>
                <th className="rm-th">Status</th>
                <th className="rm-th">Location</th>
                <th className="rm-th">Date</th>
              </tr>
            </thead>
            <tbody className="rm-table-body">
              {filteredComplaints.map(c => (
                <tr key={c._id} className="rm-table-row">
                  <td className="rm-td rm-id">{c._id.slice(0, 8)}...</td>
                  <td className="rm-td rm-title">{c.title}</td>
                  <td className="rm-td rm-category">
                    <span className="rm-category-badge">{c.category}</span>
                  </td>
                  <td className="rm-td rm-status">
                    <span className={`rm-status-badge rm-${c.status.toLowerCase().replace(' ', '-')}`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="rm-td rm-location">
                    <svg className="rm-location-icon" width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <path d="M12 12.5C13.6569 12.5 15 11.1569 15 9.5C15 7.84315 13.6569 6.5 12 6.5C10.3431 6.5 9 7.84315 9 9.5C9 11.1569 10.3431 12.5 12 12.5Z" stroke="#4F46E5" strokeWidth="2"/>
                      <path d="M12 22C16 18 20 14.4183 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14.4183 8 18 12 22Z" stroke="#4F46E5" strokeWidth="2"/>
                    </svg>
                    {c.location}
                  </td>
                  <td className="rm-td rm-date">
                    {new Date(c.date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer with Download Buttons */}
      <div className="rm-footer">
        <button 
          className="rm-download-btn rm-pdf-btn"
           onClick={downloadPDF}
        >
          <svg className="rm-download-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M12 8V16M12 16L15 13M12 16L9 13M7 3H17C18.1046 3 19 3.89543 19 5V19C19 20.1046 18.1046 21 17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Export PDF
        </button>
        <button 
          className="rm-download-btn rm-csv-btn"
          onClick={downloadCSV}
        >
          <svg className="rm-download-icon" width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M12 8V16M12 16L15 13M12 16L9 13M7 21H17C18.1046 21 19 20.1046 19 19V5C19 3.89543 18.1046 3 17 3H7C5.89543 3 5 3.89543 5 5V19C5 20.1046 5.89543 21 7 21Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Export CSV
        </button>
      </div>
    </div>
  </div>
)}








{/* vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv */}


              
              {/* Quick Actions */}
              <div className="quick-actions">
                <h2>Quick Actions</h2>
                <div className="action-buttonss">
                  <button className="action-button"  onClick={handleOpenReportModal}>
                    <span className="action-icon">📋</span>
                    Generate Report
                  </button>
                 <button
  className="action-button"
  onClick={() => window.location.href = 'tel:+91'}
>
  <span className="action-icon">📧</span>
  Contact Supervisor
</button>

                  <button className="action-button" onClick={() => setActiveTab('complaints')}>
                    <span className="action-icon">🔍</span>
                    Advanced Search
                  </button>
                </div>
              </div>
            </>
          )}
          
          {activeTab === 'complaints' && (
            <div className="complaints-management">
              {/* Filters */}
              <div className="complaint-filters">
                <div className="search-bar">
                  <input
                    type="text"
                    placeholder="Search complaints..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <span className="search-icon">🔍</span>
                </div>
                
                <div className="filter-group">
                  <label>Status:</label>
                  <select 
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                  >
                    <option value="all">All Status</option>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>
                
                <div className="filter-group">
                  <label>Category:</label>
                  <select 
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                  >
                    <option value="all">All Categories</option>
                    <option value="Road Issues">Road Issues</option>
                    <option value="Waste Management">Waste Management</option>
                    <option value="Public Utilities">Public Utilities</option>
                  </select>
                </div>
              </div>
              
              {/* Complaints Table */}
              <div className="complaints-table-container">
                <table className="complaints-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Title</th>
                      <th>Category</th>
                      <th>Status</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredComplaints.map(complaint => (
                      <tr key={complaint._id}>
                        <td>COMP-{complaint._id.slice(-6)}</td>
                        <td>{complaint.title}</td>
                        <td>
                          <span className="category-tag">
                            {getCategoryIcon(complaint.category)} {complaint.category}
                          </span>
                        </td>
                        <td>
                          <span 
                            className="status-badge"
                            style={{ backgroundColor: getStatusColor(complaint.status) }}
                          >
                            {complaint.status}
                          </span>
                        </td>
                        <td>{new Date(complaint.date).toLocaleDateString()}</td>
                        <td>
                          <button 
                            className="view-button"
                            onClick={() => openComplaintDetails(complaint)}
                          >
                            <span>

                            <FiEye className='eyee' />
                            </span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {filteredComplaints.length === 0 && (
                  <div className="no-complaints">
                    <div className="no-complaints-icon">📭</div>
                    <h3>No complaints found</h3>
                    <p>Try adjusting your search or filters</p>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {activeTab === 'stats' && (
            <div className="statistics-view">
              <h2>Complaint Statistics</h2>
              
              <div className="stats-charts">
                <div className="chart-container">
                  <h3>Status Distribution</h3>
                  <div
  className="pie-chart"
  style={{
    background: `conic-gradient(
      var(--secondary) 0deg ${((stats.resolved / stats.total) * 360).toFixed(1)}deg,
      var(--primary) ${((stats.resolved / stats.total) * 360).toFixed(1)}deg ${(((stats.resolved + stats.inProgress) / stats.total) * 360).toFixed(1)}deg,
      var(--warning) ${(((stats.resolved + stats.inProgress) / stats.total) * 360).toFixed(1)}deg 360deg
    )`
  }}
>
  <div className="pie-center">
    <span>{stats.total}</span>
    <small>Total</small>
  </div>
</div>

                  <div className="chart-legend">
                    <div className="legend-item">
                      <span className="legend-color resolved"></span>
                      Resolved ({stats.resolved})
                    </div>
                    <div className="legend-item">
                      <span className="legend-color in-progress"></span>
                      In Progress ({stats.inProgress})
                    </div>
                    <div className="legend-item">
                      <span className="legend-color pending"></span>
                      Pending ({stats.total - stats.resolved - stats.inProgress})
                    </div>
                  </div>
                </div>
                
                <div className="chart-container">
  <h3>Resolution Time</h3>
  <div className="bar-chart">
    <div className="bar-grid">
      <div className="grid-line"></div>
      <div className="grid-line"></div>
      <div className="grid-line"></div>
      <div className="grid-line"></div>
    </div>
    <div className="bars">
      {resolutionData.map((item, index) => {
        const max = 10; // assume max avg days is 10
        const heightPercent = Math.min((item.avgDays / max) * 100, 100);

        return (
          <div key={index} className="bar" style={{ height: `${heightPercent}%` }}>
            <span className="bar-value">{item.avgDays}d</span>
          </div>
        );
      })}
    </div>
    <div className="bar-labels">
      {resolutionData.map((item, index) => (
        <span key={index}>{item.category}</span>
      ))}
    </div>
  </div>
</div>

              </div>
              
              <div className="performance-metrics">
                <h3>Your Performance</h3>
                <div className="metrics-gridd">
                  <div className="metric-card">
                    <div className="metric-value">{statistics.resolutionRate}%</div>
                    <div className="metric-label">Resolution Rate</div>
                    <div className="metric-progress">
                      <div className="progress-fill" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                  
                  <div className="metric-card">
                    <div className="metric-value">{statistics.rating}</div>
                    <div className="metric-label">Avg. Rating</div>
                    <div className="metric-progress">
                      <div className="progress-fill" style={{ width: '0.1%' }}></div>
                    </div>
                  </div>
                  
                  <div className="metric-card">
                    <div className="metric-value">{statistics.avgResolutionTime}d</div>
                    <div className="metric-label">Avg. Resolution Time</div>
                    <div className="metric-progress">
                      <div className="progress-fill" style={{ width: '70%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'profile' && (
            <div className="profile-view">
              <h2>My Profile</h2>
              
              <div className="profile-card">
                <div className="profile-header">
                  <div className="profile-avatar-large">
                    {staffData.fullName.charAt(0)}
                  </div>
                  <div className="profile-info">
                    <h3>{staffData.fullName}</h3>
                    <p className="profile-role">{staffData.role}</p>
                    <p className="profile-location">📍 {staffData.location}</p>
                  </div>
                </div>
                
                <div className="profile-details">
                  <div className="detail-group">
                    <label>Email</label>
                    <p>{staffData.email}</p>
                  </div>
                  
                  <div className="detail-group">
                    <label>Assigned Location</label>
                    <p>{staffData.location}</p>
                  </div>
                  
                  <div className="detail-group">
                    <label>Member Since</label>
                    <p>{staffAccountDate ? new Date(staffAccountDate).toLocaleString('en-US', {
    month: 'long',
    year: 'numeric'
  }) : '—'}</p>
                  </div>
                </div>
                
                {/* <div className="profile-actions">
                  <button className="edit-profile-button">
                    Edit Profile
                  </button>
                  <button className="change-password-button">
                    Change Password
                  </button>
                </div> */}
              </div>
              
              <div className="profile-settings">
                <h3>Settings</h3>
                <div className="setting-item">
                  <label>Notification Preferences</label>
                  <select disabled>
                    <option>All Notifications</option>
                    <option>Only Urgent</option>
                    <option>Disabled</option>
                  </select>
                </div>
                
                <div className="setting-item">
                  <label>Theme Preference</label>
                  <select disabled>
                    <option>Light Theme</option>
                    <option>Dark Theme</option>
                    <option>System Default</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Complaint Details Modal */}
      {isModalOpen && selectedComplaint && (
        <div className="complaint-modal">
          <div className="modal-overlay" onClick={() => setIsModalOpen(false)}></div>
          <div className="modal-content">
            <button 
              className="modal-close"
              onClick={() => setIsModalOpen(false)}
            >
              &times;
            </button>
            
            <h2>{selectedComplaint.title}</h2>
            <div className="complaint-meta">
              <span className="complaint-category">
                {getCategoryIcon(selectedComplaint.category)} {selectedComplaint.category}
              </span>
              <span className="complaint-date">
                📅 {new Date(selectedComplaint.date).toLocaleDateString()}
              </span>
              <span 
                className="complaint-status"
                style={{ backgroundColor: getStatusColor(selectedComplaint.status) }}
              >
                {selectedComplaint.status}
              </span>
            </div>
            
            <div className="complaint-description">
              <h3>Description</h3>
              <p>{selectedComplaint.description}</p>
            </div>
            
            <div className="complaint-location">
              <h3>Location</h3>
              <p>📍 {selectedComplaint.location}</p>
              <div className="location-map">
                <div className="map-pin"></div>
                <div className="map-grid">
                  <div className="grid-line"></div>
                  <div className="grid-line"></div>
                  <div className="grid-line"></div>
                </div>
              </div>
            </div>
            
            {selectedComplaint.files && selectedComplaint.files.length > 0 && (
              <div className="complaint-files">
                <h3>Attachments</h3>
                <div className="file-grid">
                  {selectedComplaint.files.map((file, index) => (
                    <div key={index} className="file-item">
                      {file.endsWith('.jpg') || file.endsWith('.png') ? (
                        <img 
                          src={`${file}`} 
                          alt={`Attachment ${index + 1}`} 
                          className="file-image"
                        />
                      ) : (
                        <div className="file-icon">
                          📄
                          <span>{file.split('.').pop().toUpperCase()}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="complaint-update">
              <h3>Update Status</h3>
              <div className="update-form">
                <div className="form-group">
                  <label>New Status</label>
                  <select
                    value={statusUpdate}
                    onChange={(e) => setStatusUpdate(e.target.value)}
                  >
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Remarks</label>
                  <textarea
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Add any remarks or notes..."
                  ></textarea>
                </div>
                
                <button 
                  className="update-button"
                  onClick={handleStatusUpdate}
                >
                  Update Status
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

{/* ------------------------------------------------------------------------------------ */}

    {showUnseenModal && (
  <div className="right-notif-panel">
    <div className="right-notif-header">
      <div className="right-notif-header-content">
        <h3>New Complaints</h3>
        <div className="right-notif-count-bubble">{unseenComplaints.length}</div>
      </div>
      <button 
        className="right-notif-close"
        onClick={() => setShowUnseenModal(false)}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          <path d="M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      </button>
    </div>

    <div className="right-notif-content">
      {unseenComplaints.length === 0 ? (
        <div className="right-notif-empty">
          <div className="right-notif-empty-icon">📭</div>
          <p>No new complaints</p>
          <small>All caught up!</small>
        </div>
      ) : (
        <div className="right-notif-list">
          {unseenComplaints.map((complaint) => (
            <div key={complaint._id} className="right-notif-card">
              <div className="right-notif-card-header">
                <span className="right-notif-card-title">{complaint.title}</span>
                <span className={`right-notif-card-status ${complaint.status.replace(/\s+/g, '-').toLowerCase()}`}>
                  {complaint.status}
                </span>
              </div>
              <div className="right-notif-card-body">
                <div className="right-notif-card-category">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M9 3V5M15 3V5M9 19V21M15 19V21M5 9H3M5 15H3M21 9H19M21 15H19M7 19H17C18.1046 19 19 18.1046 19 17V7C19 5.89543 18.1046 5 17 5H7C5.89543 5 5 5.89543 5 7V17C5 18.1046 5.89543 19 7 19Z" 
                      stroke="#4B5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  {complaint.category}
                </div>
                <div className="right-notif-card-time">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" 
                      stroke="#4B5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  {new Date(complaint.createdAt).toLocaleString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
              <div className="right-notif-card-footer">
                <span className="right-notif-card-location">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M17.6569 16.6569C16.7202 17.5935 14.7616 19.5521 13.4138 20.8999C12.6327 21.681 11.3677 21.6814 10.5866 20.9003C9.26234 19.576 7.34159 17.6553 6.34315 16.6569C3.21895 13.5327 3.21895 8.46734 6.34315 5.34315C9.46734 2.21895 14.5327 2.21895 17.6569 5.34315C20.781 8.46734 20.781 13.5327 17.6569 16.6569Z" 
                      stroke="#4B5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M15 11C15 12.6569 13.6569 14 12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11Z" 
                      stroke="#4B5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  {complaint.location}
                </span>
                <button className="right-notif-card-action" onClick={() => handleComplaintClick(complaint)} >
                  View Details
                </button>
              </div>
            
            </div>
          ))}
        </div>
      )}
    </div>
  </div>
)}

    </div>
  );
};

export default StaffDashboard;