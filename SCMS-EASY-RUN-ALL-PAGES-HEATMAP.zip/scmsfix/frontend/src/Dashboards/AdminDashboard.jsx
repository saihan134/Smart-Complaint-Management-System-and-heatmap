import { useState, useEffect } from 'react';
import axios from 'axios';
import { FiUsers, FiAlertCircle, FiCheckCircle, FiClock, FiMapPin, FiSettings, FiPieChart, FiFileText, FiMessageSquare, FiTrash2, FiEdit, FiEye, FiDownload } from 'react-icons/fi';
import { FiLogOut } from 'react-icons/fi';
import '../Styles/AdminDashboard.css';
import ComplaintHeatmap from '../Components/ComplaintHeatmap';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell,
  BarChart, Bar
} from 'recharts';
const API_BASE = '/api';
const DEMO_COMPLAINTS = [
  { _id: 'demo-1', title: 'Road potholes near bus stand', description: 'Multiple potholes reported.', category: 'Road Issues (e.g., potholes)', location: 'Chennai', coordinates: { lat: 13.0827, lng: 80.2707 }, status: 'Pending', date: new Date().toISOString() },
  { _id: 'demo-2', title: 'Overflowing garbage bins', description: 'Waste collection is delayed.', category: 'Waste Management', location: 'Chennai', coordinates: { lat: 13.0674, lng: 80.2376 }, status: 'In Progress', date: new Date().toISOString() },
  { _id: 'demo-3', title: 'Streetlight not working', description: 'Streetlight is off at night.', category: 'Streetlight / Electrical', location: 'Coimbatore', coordinates: { lat: 11.0168, lng: 76.9558 }, status: 'Resolved', date: new Date().toISOString() },
  { _id: 'demo-4', title: 'Water supply interruption', description: 'Water unavailable since morning.', category: 'Water Supply', location: 'Madurai', coordinates: { lat: 9.9252, lng: 78.1198 }, status: 'Pending', date: new Date().toISOString() },
  { _id: 'demo-5', title: 'Drainage issue', description: 'Blocked drainage after rain.', category: 'Sanitation', location: 'Puducherry', coordinates: { lat: 11.9416, lng: 79.8083 }, status: 'In Progress', date: new Date().toISOString() }
];




const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState(() => new URLSearchParams(window.location.search).get('tab') === 'heatmap' ? 'heatmap' : 'dashboard');
  const [userTab, setUserTab] = useState('citizens');
  const [complaints, setComplaints] = useState(() => new URLSearchParams(window.location.search).get('demo') === '1' ? DEMO_COMPLAINTS : []);
  const [users, setUsers] = useState(() => new URLSearchParams(window.location.search).get('demo') === '1' ? [{ _id: 'demo-citizen', fullName: 'Demo Citizen', role: 'citizen' }, { _id: 'demo-staff', fullName: 'Demo Staff', role: 'staff' }] : []);
  const [stats, setStats] = useState({
    totalComplaints: 0,
    pending: 0,
    inProgress: 0,
    resolved: 0,
    activeStaff: 0,
    registeredCitizens: 0,
    todaysComplaints: 0
  });
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterLocation, setFilterLocation] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [trendData, setTrendData] = useState([]);
const [categoryData, setCategoryData] = useState([]);
const [resolutionData, setResolutionData] = useState([]);
const [heatmapData, setHeatmapData] = useState([]);
const [showLogoutModal, setShowLogoutModal] = useState(false);
const [analyticsData, setAnalyticsData] = useState({
  complaintsTrend: [],
  categoryDistribution: [],
  statusDistribution: [],
  averageResolutionTime: 0,
  locationData: []
});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reportFilters, setReportFilters] = useState({
    timePeriod: '30days',
    reportType: 'complaints-summary',
    format: 'pdf'
  });

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const categoryIcons = {
  'Road Issues (e.g., potholes)': '🛣️',          // road symbol
  'Waste Management': '🗑️',                      // trash bin
  'Streetlight / Electrical': '💡',               // light bulb
  'Water Supply': '🚰',                            // flashlight
  'Noise Pollution': '🔊',                        // speaker
  'Sanitation': '🚽',                            // toilet (common sanitation symbol)
  'Others': '❓'                                  // question mark
};




 useEffect(() => {
  const fetchAnalyticsData = async () => {
  try {
    setLoading(true);
    const response = await axios.get(`${API_BASE}/analytics/summary`);
    setAnalyticsData({
      complaintsTrend: response.data.complaintsTrend || [],
      categoryDistribution: response.data.categoryDistribution || [],
      statusDistribution: response.data.statusDistribution || [],
      averageResolutionTime: response.data.averageResolutionTime || 0,
      locationData: response.data.locationData || []
    });
    setLoading(false);
  } catch (err) {
    setError('Failed to load analytics data');
    setLoading(false);
    console.error(err);
  }
};

    fetchAnalyticsData();
  }, []);

const handleGenerateReport = async () => {
  try {
    const { format } = reportFilters;

    if (format === 'pdf') {
      const response = await axios.get(`${API_BASE}/analytics/custom-report`, {
        params: reportFilters,
        responseType: 'blob'
      });
      downloadFile(response.data, 'application/pdf', 'pdf');
      return;
    }

    const response = await axios.get(`${API_BASE}/analytics/custom-report`, {
      params: { ...reportFilters, format: 'json' }
    });

    if (format === 'csv') {
      generateCSV(response.data);
    } else if (format === 'excel') {
      generateExcel(response.data);
    }

  } catch (err) {
    console.error('Report generation failed:', err);
    alert('Failed to generate report. Please try again.');
  }
};

// ✅ Helper Functions

function downloadFile(data, mimeType, extension) {
  const blob = new Blob([data], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `report_${new Date().toISOString().slice(0, 10)}.${extension}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function generateCSV(data) {
  if (!data || data.length === 0) {
    alert("No data to export");
    return;
  }
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(obj =>
    Object.values(obj).map(val =>
      `"${String(val).replace(/"/g, '""')}"`
    ).join(',')
  );
  const csvContent = [headers, ...rows].join('\n');
  downloadFile(csvContent, 'text/csv;charset=utf-8;', 'csv');
}

async function generateExcel(data) {
  if (!data || data.length === 0) {
    alert("No data to export");
    return;
  }
  const { utils, write } = await import('xlsx');
  const ws = utils.json_to_sheet(data);
  const wb = utils.book_new();
  utils.book_append_sheet(wb, ws, "Report");

  const wbout = write(wb, { bookType: "xlsx", type: "array" });
  downloadFile(wbout, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xlsx');
}

const handleFilterChange = (e) => {
  const { name, value } = e.target;
  setReportFilters(prev => ({
    ...prev,
    [name]: value
  }));
};


   useEffect(() => {
    const fetchData = async () => {
      try {
        const [complaintsRes, usersRes] = await Promise.all([
          axios.get(`${API_BASE}/complaints`),
          axios.get(`${API_BASE}/users`)
        ]);

        const complaintsData = complaintsRes.data;
        const usersData = usersRes.data;

        const isDemo = new URLSearchParams(window.location.search).get('demo') === '1';
        if (!isDemo || complaintsData.length) setComplaints(complaintsData);
        if (!isDemo || usersData.length) setUsers(usersData);

        const totalComplaints = complaintsData.length;
        const pending = complaintsData.filter(c => c.status === 'Pending').length;
        const inProgress = complaintsData.filter(c => c.status === 'In Progress').length;
        const resolved = complaintsData.filter(c => c.status === 'Resolved').length;
        const activeStaff = usersData.filter(u => u.role === 'staff').length;
        const registeredCitizens = usersData.filter(u => u.role === 'citizen').length;
        const todaysComplaints = complaintsData.filter(c => new Date(c.date).toDateString() === new Date().toDateString()).length;

        setStats({
          totalComplaints,
          pending,
          inProgress,
          resolved,
          activeStaff,
          registeredCitizens,
          todaysComplaints
        });

        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleStatusChange = async (complaintId, newStatus) => {
    try {
      await axios.put(`${API_BASE}/complaints/${complaintId}/status`, { status: newStatus });
      setComplaints(prev => prev.map(c => c._id === complaintId ? { ...c, status: newStatus } : c));
    } catch (err) {
      console.error('Error updating complaint status:', err);
    }
  };

  useEffect(() => {
  const fetchAnalytics = async () => {
    try {
      const [trend, category, resolution, heatmap] = await Promise.all([
        axios.get(`${API_BASE}/analytics/complaints-trend`),
        axios.get(`${API_BASE}/analytics/category-distribution`),
        axios.get(`${API_BASE}/analytics/resolution-time`),
        axios.get(`${API_BASE}/analytics/location-heatmap`),
      ]);
      setTrendData(trend.data);
      setCategoryData(category.data);
      setResolutionData(resolution.data);
      setHeatmapData(heatmap.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    }
  };

  fetchAnalytics();
}, []);


  const handleExportComplaints = (format = 'csv') => {
  if (filteredComplaints.length === 0) {
    alert('No complaints to export');
    return;
  }

  let content, mimeType, extension;

  if (format === 'csv') {
    // CSV export logic
    const headers = ['ID', 'Title', 'Description', 'Category', 'Location', 'Status', 'Date'];
    const rows = filteredComplaints.map(complaint => [
      `#${complaint._id.slice(-6)}`,
      `"${complaint.title.replace(/"/g, '""')}"`,
      `"${complaint.description.replace(/"/g, '""')}"`,
      complaint.category,
      complaint.location,
      complaint.status,
      new Date(complaint.date).toLocaleDateString()
    ]);

    content = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    mimeType = 'text/csv;charset=utf-8;';
    extension = 'csv';
  } else if (format === 'json') {
    // JSON export logic
    content = JSON.stringify(filteredComplaints, null, 2);
    mimeType = 'application/json';
    extension = 'json';
  }

  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `complaints_export_${new Date().toISOString().slice(0, 10)}.${extension}`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

  const handleDeleteComplaint = async (complaintId) => {
    try {
      await axios.delete(`${API_BASE}/complaints/${complaintId}`);
      setComplaints(prev => prev.filter(c => c._id !== complaintId));
    } catch (err) {
      console.error('Error deleting complaint:', err);
    }
  };

    const handleUserAction = async (userId, action) => {
    try {
      if (action === 'delete') {
        await axios.delete(`${API_BASE}/users/${userId}`);
        setUsers(prev => prev.filter(u => u._id !== userId));
      } else if (action === 'promote') {
        await axios.put(`${API_BASE}/users/${userId}/promote`, { role: 'staff' });
        setUsers(prev => prev.map(u => u._id === userId ? { ...u, role: 'staff' } : u));
      }
    } catch (err) {
      console.error('Error performing user action:', err);
    }
  };


  // Build the heatmap from the complaints already returned by the API.
  // The current Complaint model stores a location name (not latitude/longitude),
  // so the admin heatmap represents complaint concentration by reported location.
  const heatmapLocations = (() => {
    const grouped = {};
    complaints.forEach((complaint) => {
      const location = (complaint.location || 'Unknown Location').trim() || 'Unknown Location';
      grouped[location] = (grouped[location] || 0) + 1;
    });

    const values = Object.entries(grouped)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    const max = values[0]?.count || 1;
    return values.map((item, index) => {
      const ratio = item.count / max;
      // Clear civic-priority bands: 5+ high, 2-4 medium, 1 low.
      const level = item.count >= 5 ? 'high' : item.count >= 2 ? 'medium' : 'low';
      // Stable pseudo positions: unlike Math.random(), these do not jump on every render.
      let hash = 0;
      for (let i = 0; i < item.name.length; i += 1) hash = ((hash << 5) - hash) + item.name.charCodeAt(i);
      const normalized = Math.abs(hash);
      return {
        ...item,
        level,
        top: 12 + (normalized % 72),
        left: 10 + ((Math.floor(normalized / 97)) % 80),
        size: 34 + Math.round(ratio * 38)
      };
    });
  })();

  const heatmapTotals = {
    high: heatmapLocations.filter(item => item.level === 'high').reduce((sum, item) => sum + item.count, 0),
    medium: heatmapLocations.filter(item => item.level === 'medium').reduce((sum, item) => sum + item.count, 0),
    low: heatmapLocations.filter(item => item.level === 'low').reduce((sum, item) => sum + item.count, 0)
  };

const filteredComplaints = complaints.filter(complaint => {
  const matchesSearch = complaint.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                       complaint.description.toLowerCase().includes(searchTerm.toLowerCase());
  const matchesStatus = filterStatus === 'all' || complaint.status === filterStatus;
  const matchesCategory = filterCategory === 'all' || complaint.category === filterCategory;
  const matchesLocation = filterLocation === 'all' || complaint.location === filterLocation;
  
  return matchesSearch && matchesStatus && matchesCategory && matchesLocation;
});

  const citizenUsers = users.filter(u => u.role === 'citizen');
  const staffUsers = users.filter(u => u.role === 'staff');

  if (isLoading) {
    return (
      <div className="admin-loading">
        <div className="loading-spiral"></div>
        <p>Loading Dashboard...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      {/* Sidebar */}
      <div className="admin-sidebar">
        <div className="sidebar-header">
          <div className="admin-avatar">A</div>
          <h3>Admin Panel</h3>
        </div>
        
        <nav className="sidebar-nav">
          <button 
            className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <FiPieChart className="nav-icon" />
            <span className="nav-label">Dashboard</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'heatmap' ? 'active' : ''}`}
            onClick={() => setActiveTab('heatmap')}
          >
            <FiMapPin className="nav-icon" />
            <span className="nav-label">Complaint Heatmap</span>
          </button>

          <button 
            className={`nav-item ${activeTab === 'complaints' ? 'active' : ''}`}
            onClick={() => setActiveTab('complaints')}
          >
            <FiAlertCircle className="nav-icon" />
            <span className="nav-label">Complaints</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            <FiUsers className="nav-icon" />
            <span className="nav-label">User Management</span>
            
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveTab('analytics')}
          >
            <FiFileText className="nav-icon" />
            <span className="nav-label">Analytics</span>
          </button>
          
          <button className=" nav-item settings-button mobile_logout"   onClick={() => setShowLogoutModal(true)}>
            <FiLogOut className="nav-icon" />
             <span className="nav-label">Logout</span>
          </button>
         
        </nav>
        
        <div className="sidebar-footer">
          <button className="settings-button"   onClick={() => setShowLogoutModal(true)}>
            <FiLogOut className="nav-icon" />
            Logout
          </button>
        </div>
      </div>
      
{/* -------------------------------- */}




{showLogoutModal && (
  <div className="authflow-logout-overlay" onClick={() => setShowLogoutModal(false)}>
    <div className="authflow-logout-dialog" onClick={e => e.stopPropagation()}>
      <div className="authflow-logout-icon">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 3V6M12 18V21M5 12H3M21 12H16M6.2 7.8L4 5.5M17.8 7.8L20 5.5M6.2 16.2L4 18.5M17.8 16.2L20 18.5M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h3 className="authflow-logout-title">Ready to leave?</h3>
      <p className="authflow-logout-message">Are you sure you want to log out of your account?</p>
      <div className="authflow-logout-actions">
        <button
          className="authflow-logout-secondary"
          onClick={() => setShowLogoutModal(false)}
        >
          Stay logged in
        </button>
        <button
          className="authflow-logout-primary"
          onClick={() => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            setShowLogoutModal(false);
            
            window.location.href = '/login';

          }}
        >
          Log out
        </button>
      </div>
    </div>
  </div>
)}




{/* ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; */}





      
      {/* Main Content */}
      <div className="admin-main">
        <header className="admin-header">
          <h1>
            {activeTab === 'dashboard' && 'Dashboard Overview'}
            {activeTab === 'complaints' && 'Complaint Management'}
            {activeTab === 'heatmap' && 'Complaint Heatmap'}
            {activeTab === 'users' && 'User Management'}
            {activeTab === 'analytics' && 'Analytics & Reports'}
            {activeTab === 'feedback' && 'Feedback & Remarks'}
          </h1>
          
          <div className="header-actions">
          
         
          </div>
        </header>
        
        <div className="admin-content">
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div className="dashboard-overview">
              {/* Stats Cards */}
              <div className="stats-grid">
                <div className="stat-card primary">
                  <div className="stat-icon">
                    <FiAlertCircle />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.totalComplaints}</h3>
                    <p>Total Complaints</p>
                  </div>
                </div>
                
                <div className="stat-card warning">
                  <div className="stat-icon">
                    <FiClock />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.pending}</h3>
                    <p>Pending</p>
                  </div>
                </div>
                
                <div className="stat-card info">
                  <div className="stat-icon">
                    <FiAlertCircle />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.inProgress}</h3>
                    <p>In Progress</p>
                  </div>
                </div>
                
                <div className="stat-card success">
                  <div className="stat-icon">
                    <FiCheckCircle />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.resolved}</h3>
                    <p>Resolved</p>
                  </div>
                </div>
                
                <div className="stat-card secondary">
                  <div className="stat-icon">
                    <FiUsers />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.activeStaff}</h3>
                    <p>Active Staff</p>
                  </div>
                </div>
                
                <div className="stat-card dark">
                  <div className="stat-icon">
                    <FiUsers />
                  </div>
                  <div className="stat-info">
                    <h3>{stats.registeredCitizens}</h3>
                    <p>Citizens</p>
                  </div>
                </div>
              </div>
              
              {/* Complaint Heatmap Preview */}
              <div className="dashboard-heatmap-card">
                <div className="heatmap-card-header">
                  <div>
                    <span className="heatmap-kicker">LIVE LOCATION INTELLIGENCE</span>
                    <h3>Complaint Heatmap</h3>
                    <p>Identify areas with high, medium and low complaint concentration.</p>
                  </div>
                  <button className="heatmap-open-button" onClick={() => setActiveTab('heatmap')}>
                    View Full Heatmap →
                  </button>
                </div>

                <div className="heatmap-legend">
                  <span><i className="heat-dot high"></i> High</span>
                  <span><i className="heat-dot medium"></i> Medium</span>
                  <span><i className="heat-dot low"></i> Low</span>
                </div>

                <ComplaintHeatmap complaints={complaints} compact />
              </div>

              {/* Charts Row */}
              <div className="charts-row">
                <div className="chart-container">
                  <h3>Complaints by Status</h3>
                  <div className="pie-chart">
                    <div className="chart-visual"></div>
                    <div className="chart-legend">
                      <div className="legend-item">
                        <span className="color-dot pending"></span>
                        <span>Pending ({stats.pending})</span>
                      </div>
                      <div className="legend-item">
                        <span className="color-dot in-progress"></span>
                        <span>In Progress ({stats.inProgress})</span>
                      </div>
                      <div className="legend-item">
                        <span className="color-dot resolved"></span>
                        <span>Resolved ({stats.resolved})</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="chart-container">
                  <h3>Complaints by Location</h3>
                  <div className="bar-chart">
                    <div className="chart-visual"></div>
                    <div className="chart-labels">
                      <span>Tenkasi</span>
                      <span>Madurai</span>
                      <span>Chennai</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Recent Activity */}
              <div className="recent-activity">
                <h3>Recent Complaints</h3>
                <div className="activity-list">
                  {complaints.slice(0, 5).map(complaint => (
                    <div key={complaint._id} className="activity-item">
                      <div className="activity-icon">
                      <span>{categoryIcons[complaint.category] || '📌'}</span>

                      </div>
                      <div className="activity-details">
                        <h4>{complaint.title}</h4>
                        <p>{complaint.location} • {new Date(complaint.date).toLocaleDateString()}</p>
                      </div>
                      <span className={`status-badge ${complaint.status.toLowerCase().replace(' ', '-')}`}>
                        {complaint.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Complaints Tab */}
          {activeTab === 'complaints' && (
            <div className="complaints-management">
              <div className="section-header">
                <h2>Manage Complaints</h2>
               <div className="header-actions">
  <div className="export-dropdown">
    <button className="export-button">
      <FiDownload /> Export
    </button>
    <div className="export-dropdown-content">
      <button onClick={() => handleExportComplaints('csv')}>CSV</button>
      <button onClick={() => handleExportComplaints('json')}>JSON</button>
    </div>
  </div>
</div>
              </div>
              
              <div className="filters-row">
                <div className="filter-group">
                  <label>Status</label>
                  <select 
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                  >
                    <option value="all">All Status</option>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>
                
                <div className="filter-group">
                  <label>Category</label>
                  <select 
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                  >
                    <option value="all">All Categories</option>
                    <option value="Road Issues">Road Issues</option>
                    <option value="Waste Management">Waste Management</option>
                    <option value="Public Utilities">Public Utilities</option>
                  </select>
                </div>
                
                <div className="filter-group">
                  <label>Location</label>
                  <select 
                    value={filterLocation}
                    onChange={(e) => setFilterLocation(e.target.value)}
                  >
                    <option value="all">All Locations</option>
                    <option value="Tenkasi">Tenkasi</option>
                    <option value="Madurai">Madurai</option>
                    <option value="Chennai">Chennai</option>
                  </select>
                </div>
              </div>
              
              <div className="complaints-table-container">
                <table className="complaints-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Title</th>
                      <th>Category</th>
                      <th>Location</th>
                      <th>Status</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredComplaints.map(complaint => (
                      <tr key={complaint._id}>
                        <td>#{complaint._id.slice(-6)}</td>
                        <td className="title-cell">
                          <div className="complaint-title">{complaint.title}</div>
                          <div className="complaint-desc">{complaint.description.slice(0, 50)}...</div>
                        </td>
                        <td>
                          <span className="category-tag">
                         <span>{categoryIcons[complaint.category] || '📌'}</span>
                            {complaint.category}
                          </span>
                        </td>
                        <td>
                          <span className="location-tag">
                            <FiMapPin /> {complaint.location}
                          </span>
                        </td>
                        <td>
                          <select
                            value={complaint.status}
                            onChange={(e) => handleStatusChange(complaint._id, e.target.value)}
                            className={`status-select ${complaint.status.toLowerCase().replace(' ', '-')}`}
                          >
                            <option value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                          </select>
                        </td>
                        <td>{new Date(complaint.date).toLocaleDateString()}</td>
                        <td>
                          <div className="action-buttons">
                            <button  
                              className="view-button"
                              onClick={() => {
                                setSelectedComplaint(complaint);
                                setIsModalOpen(true);
                              }}
                            >
                            


<div className='eyebtn' style={{ fontSize: '21px', color: '#4361ee' , display:"flex",alignItems:"center",justifyContent:"center"}}>
  <FiEye />
</div>



                            </button>
                            <button 
                              className="delete-button"
                              onClick={() => handleDeleteComplaint(complaint._id)}
                            >
                              <FiTrash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                
                {filteredComplaints.length === 0 && (
                  <div className="no-results">
                    <p>No complaints found matching your criteria</p>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Users Tab */}
          {activeTab === 'users' && (
            <div className="users-management">
              <div className="section-header">
                <h2>User Management</h2>
                <div className="tabs">
                  <button 
                    className={`tab-button ${userTab === 'citizens' ? 'active' : ''}`}
                    onClick={() => setUserTab('citizens')}
                  >
                    Citizens
                  </button>
                  <button 
                    className={`tab-button ${userTab === 'staff' ? 'active' : ''}`}
                    onClick={() => setUserTab('staff')}
                  >
                    Staff
                  </button>
                </div>
              </div>
              
              {userTab === 'citizens' ? (
                <div className="users-table-container">
                  <table className="users-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Complaints</th>
                        <th>Joined</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {citizenUsers.map(user => (
                        <tr key={user._id}>
                          <td>{user.fullName}</td>
                          <td>{user.email}</td>
                          <td>{user.location}</td>
                          <td>
                            {complaints.filter(c => c.userId === user._id).length}
                          </td>
                          <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                          <td>
                            <div className="action-buttons">
                              <button 
                                className="view-button"
                                onClick={() => {
                                  setSelectedUser(user);
                                  setIsUserModalOpen(true);
                                }}
                              >
                               <div  className='eyebtn' style={{ fontSize: '21px', color: '#4361ee' , display:"flex",alignItems:"center",justifyContent:"center"}}>
  <FiEye />
</div>
                              </button>
                              <button 
                                className="delete-button"
                                onClick={() => handleUserAction(user._id, 'delete')}
                              >
                                <FiTrash2 />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="users-table-container">
                  <table className="users-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Assigned</th>
                        <th>Resolved</th>
                        <th>Performance</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {staffUsers.map(user => (
                        <tr key={user._id}>
                          <td>{user.fullName}</td>
                          <td>{user.email}</td>
                          <td>{user.location}</td>
                          <td>
                            {complaints.filter(c => c.status !== 'Resolved' && c.location === user.location).length}
                          </td>
                          <td>
                            {complaints.filter(c => c.status === 'Resolved' && c.location === user.location).length}
                          </td>
                          <td>
                            <div className="performance-bar">
                              <div 
                                className="progress-fill"
                                style={{ width: '75%' }}
                              ></div>
                              <span>75%</span>
                            </div>
                          </td>
                          <td>
                            <div className="action-buttons">
                              <button 
                                className="view-button"
                                onClick={() => {
                                  setSelectedUser(user);
                                  setIsUserModalOpen(true);
                                }}
                              >
                               <div className='eyebtn' style={{ fontSize: '21px', color: '#4361ee' , display:"flex",alignItems:"center",justifyContent:"center"}}>
  <FiEye />
</div>
                              </button>
                              
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
          
          {/* Real geographic Complaint Heatmap */}
          {activeTab === 'heatmap' && (
            <div className="analytics-view">
              <div className="section-header">
                <div>
                  <span className="heatmap-kicker">LIVE LOCATION INTELLIGENCE</span>
                  <h2>Complaint Heatmap</h2>
                  <p>Real geographic complaint concentration from complaint coordinates or location names.</p>
                </div>
              </div>
              <ComplaintHeatmap complaints={complaints} />
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === 'analytics' && (
  <div className="analytics-view">
    <div className="section-header">
      <h2>Analytics & Reports</h2>
      <div className="header-actions">
        <button onClick={handleGenerateReport} className="export-button">
          <FiDownload /> Export Report
        </button>
      </div>
    </div>
    
    {loading ? (
      <div className="loading">Loading analytics data...</div>
    ) : error ? (
      <div className="error">{error}</div>
    ) : (
      <>
        <div className="analytics-grid">
          {/* Complaints Trend Chart */}
          <div className="analytics-card large">
            <h3>Complaints Trend (Last 30 Days)</h3>
            <div className="line-chart">
              {analyticsData.complaintsTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analyticsData.complaintsTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="_id" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="count" 
                      stroke="#8884d8" 
                      activeDot={{ r: 8 }} 
                      name="Complaints"
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No trend data available</div>
              )}
            </div>
          </div>
          
          {/* Category Distribution Chart */}
          <div className="analytics-card">
            <h3>Category Distribution</h3>
            <div className="donut-chart">
              {analyticsData.categoryDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analyticsData.categoryDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      nameKey="_id"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {analyticsData.categoryDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No category data available</div>
              )}
            </div>
          </div>
          
          {/* Resolution Time Chart */}
          <div className="analytics-card">
            <h3>Resolution Time</h3>
            <div className="resolution-metric">
              <div className="resolution-value">
                {analyticsData.averageResolutionTime.toFixed(1)} days
              </div>
              <div className="resolution-label">Average Time to Resolve</div>
            </div>
            <div className="bar-chart-vertical">
              {analyticsData.statusDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={analyticsData.statusDistribution}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="_id" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" name="Complaints" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No status data available</div>
              )}
            </div>
          </div>
          
          {/* Location Heatmap */}
          <div className="analytics-card large">
            <div className="heatmap-panel-title">
              <div><FiMapPin /> <span>Location Heatmap</span></div>
              <button className="heatmap-open-button" onClick={() => setActiveTab('heatmap')}>Open Heatmap →</button>
            </div>
            <div className="heatmap-canvas compact">
              <div className="heatmap-grid"></div>
              {heatmapLocations.slice(0, 12).map((item) => (
                <button
                  type="button"
                  key={item.name}
                  className={`heatmap-point ${item.level}`}
                  style={{ top: `${item.top}%`, left: `${item.left}%`, width: `${item.size}px`, height: `${item.size}px` }}
                  title={`${item.name}: ${item.count} complaint${item.count === 1 ? '' : 's'}`}
                  onClick={() => setActiveTab('heatmap')}
                >
                  <span>{item.count}</span>
                </button>
              ))}
              {heatmapLocations.length === 0 && <div className="heatmap-empty">No complaint locations available yet.</div>}
            </div>
            <div className="heatmap-legend">
              <span><i className="heat-dot high"></i> High (5+)</span>
              <span><i className="heat-dot medium"></i> Medium (2-4)</span>
              <span><i className="heat-dot low"></i> Low (1)</span>
            </div>
          </div>
        </div>
        
        {/* Custom Report Section */}
<div className="report-options">
  <h3>Generate Custom Report</h3>
  <div className="report-filters">
    <div className="filter-group">
      <label>Time Period</label>
      <select 
        name="timePeriod"
        value={reportFilters.timePeriod}
        onChange={handleFilterChange}
      >
        <option value="7days">Last 7 Days</option>
        <option value="30days">Last 30 Days</option>
        <option value="quarter">Last Quarter</option>
      </select>
    </div>
    
    <div className="filter-group">
      <label>Report Type</label>
      <select 
        name="reportType"
        value={reportFilters.reportType}
        onChange={handleFilterChange}
      >
        <option value="complaints-summary">Complaints Summary</option>
        <option value="staff-performance">Staff Performance</option>
        <option value="category-analysis">Category Analysis</option>
      </select>
    </div>
    
    <div className="filter-group">
      <label>Format</label>
      <select 
        name="format"
        value={reportFilters.format}
        onChange={handleFilterChange}
      >
        <option value="pdf">PDF</option>
        <option value="csv">CSV</option>
        <option value="excel">Excel</option>
      </select>
    </div>
    
    <button 
      className="generate-button"
      onClick={handleGenerateReport}
      disabled={loading}
    >
      {loading ? 'Generating...' : 'Download Report'}
    </button>
  </div>
</div>
      </>
    )}
  </div>
)}
          
          
        </div>
      </div>
      
      {/* Complaint Details Modal */}
      {isModalOpen && selectedComplaint && (
        <div className="admin-modal">
          <div className="modal-overlay" onClick={() => setIsModalOpen(false)}></div>
          <div className="modal-content">
            <button className="modal-close" onClick={() => setIsModalOpen(false)}>
              &times;
            </button>
            
            <h2>{selectedComplaint.title}</h2>
            <div className="modal-header">
              <span className="complaint-category">
                {selectedComplaint.category === 'Road Issues' ? '🚧' : 
                 selectedComplaint.category === 'Waste Management' ? '🗑️' : '💡'}
                {selectedComplaint.category}
              </span>
              <span className="complaint-location">
                <FiMapPin /> {selectedComplaint.location}
              </span>
              <span className={`complaint-status ${selectedComplaint.status.toLowerCase().replace(' ', '-')}`}>
                {selectedComplaint.status}
              </span>
            </div>
            
            <div className="modal-section">
              <h3>Description</h3>
              <p>{selectedComplaint.description}</p>
            </div>
            
            <div className="modal-section">
              <h3>Attachments</h3>
              <div className="attachments-grid">
                {selectedComplaint.files.map((file, index) => (
                  <div key={index} className="attachment-item">
                    {file.endsWith('.jpg') || file.endsWith('.png') ? (
                      <img 
                        src={`/uploads/${file}`} 
                        alt={`Attachment ${index + 1}`} 
                        className="attachment-image"
                      />
                    ) : (
                      <div className="file-icon">
                        📄
                        <span>{file.split('.').pop().toUpperCase()}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="modal-section">
              <h3>Remarks</h3>
              {selectedComplaint.remarks && selectedComplaint.remarks.length > 0 ? (
                <div className="remarks-list">
                  {selectedComplaint.remarks.map((remark, index) => (
                    <div key={index} className="remark-item">
                      <p>{remark.message}</p>
                      <span className="remark-date">
                        {new Date(remark.timestamp).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p>No remarks yet</p>
              )}
            </div>
            
            <div className="modal-actions">
              <button  onClick={() => setIsModalOpen(false)} className="modal-button secondary">
                Close
              </button>
           
            </div>
          </div>
        </div>
      )}
      
      {/* User Details Modal */}
      {isUserModalOpen && selectedUser && (
        <div className="admin-modal">
          <div className="modal-overlay" onClick={() => setIsUserModalOpen(false)}></div>
          <div className="modal-content">
            <button className="modal-close" onClick={() => setIsUserModalOpen(false)}>
              &times;
            </button>
            
            <div className="user-header">
              <div className="user-avatar">
                {selectedUser.fullName.charAt(0)}
              </div>
              <div className="user-info">
                <h2>{selectedUser.fullName}</h2>
                <p className="user-role">{selectedUser.role}</p>
                <p className="user-location">
                  <FiMapPin /> {selectedUser.location}
                </p>
              </div>
            </div>
            
            <div className="modal-section">
              <h3>Contact Information</h3>
              <div className="info-grid">
                <div className="info-item">
                  <label>Email</label>
                  <p>{selectedUser.email}</p>
                </div>
                <div className="info-item">
                  <label>Phone</label>
                  <p>{selectedUser.phone}</p>
                </div>
                <div className="info-item">
                  <label>Address</label>
                  <p>{selectedUser.address || 'Not provided'}</p>
                </div>
                <div className="info-item">
                  <label>Member Since</label>
                  <p>{new Date(selectedUser.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
            </div>
            
            {selectedUser.role === 'citizen' && (
              <div className="modal-section">
                <h3>Complaint History</h3>
                <div className="complaints-mini-list">
                  {complaints.filter(c => c.userId === selectedUser._id).slice(0, 3).map(complaint => (
                    <div key={complaint._id} className="complaint-item">
                      <h4>{complaint.title}</h4>
                      <div className="complaint-meta">
                        <span>{complaint.category}</span>
                        <span>{new Date(complaint.date).toLocaleDateString()}</span>
                        <span className={`status ${complaint.status.toLowerCase().replace(' ', '-')}`}>
                          {complaint.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {selectedUser.role === 'staff' && (
              <div className="modal-section">
                <h3>Performance Metrics</h3>
                <div className="metrics-grid">
                  <div className="metric-card">
                    <h4>Assigned Complaints</h4>
                    <p className="metric-value">
                      {complaints.filter(c => c.status !== 'Resolved' && c.location === selectedUser.location).length}
                    </p>
                  </div>
                  <div className="metric-card">
                    <h4>Resolved Complaints</h4>
                    <p className="metric-value">
                      {complaints.filter(c => c.status === 'Resolved' && c.location === selectedUser.location).length}
                    </p>
                  </div>
                  <div className="metric-card">
                    <h4>Resolution Rate</h4>
                    <p className="metric-value">75%</p>
                  </div>
                  <div className="metric-card">
                    <h4>Avg. Resolution Time</h4>
                    <p className="metric-value">3.2 days</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="modal-actions">
           
              <button  onClick={() => setIsUserModalOpen(false)} className="modal-button primary">
               Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;