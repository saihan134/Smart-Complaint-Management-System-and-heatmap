import React, { useEffect, useRef, useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import '../Styles/Signup.css';
import axios from 'axios';

function Signup() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    role: 'citizen',
    address: '',
    location: '',
    latitude: '',
    longitude: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerRef = useRef(null);
  const [locations, setLocations] = useState([]);
  const [mapReady, setMapReady] = useState(false);

  useEffect(() => {
    const loadLocations = async () => {
      try {
        const response = await axios.get('/api/locations');
        setLocations(response.data);
      } catch (error) {
        console.error('Unable to load locations:', error);
        setLocations([
          { name: 'Chennai', latitude: 13.0827, longitude: 80.2707 },
          { name: 'Coimbatore', latitude: 11.0168, longitude: 76.9558 },
          { name: 'Madurai', latitude: 9.9252, longitude: 78.1198 },
          { name: 'Tiruchirappalli', latitude: 10.7905, longitude: 78.7047 },
          { name: 'Tenkasi', latitude: 8.9597, longitude: 77.3152 },
          { name: 'Sankarankoil', latitude: 9.1756, longitude: 77.5437 }
        ]);
      }
    };
    loadLocations();
  }, []);

  useEffect(() => {
    if (!mapRef.current || !window.L || mapInstanceRef.current) return;

    const L = window.L;
    const defaultCenter = [10.8505, 78.7047];
    const map = L.map(mapRef.current, { scrollWheelZoom: true }).setView(defaultCenter, 7);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    const marker = L.marker(defaultCenter, { draggable: true }).addTo(map);
    marker.bindPopup('Drag this pin or click the map to choose your exact location.').openPopup();

    const updateCoordinates = (lat, lng) => {
      setFormData(prev => ({ ...prev, latitude: Number(lat.toFixed(6)), longitude: Number(lng.toFixed(6)) }));
    };

    map.on('click', event => {
      marker.setLatLng(event.latlng);
      updateCoordinates(event.latlng.lat, event.latlng.lng);
    });
    marker.on('dragend', event => {
      const position = event.target.getLatLng();
      updateCoordinates(position.lat, position.lng);
    });

    mapInstanceRef.current = map;
    markerRef.current = marker;
    setMapReady(true);
    setTimeout(() => map.invalidateSize(), 100);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      markerRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapReady || !formData.location || !mapInstanceRef.current || !markerRef.current) return;
    const selected = locations.find(item => item.name === formData.location);
    if (!selected) return;

    const position = [selected.latitude, selected.longitude];
    markerRef.current.setLatLng(position);
    mapInstanceRef.current.setView(position, 13, { animate: true });
    setFormData(prev => ({
      ...prev,
      latitude: selected.latitude,
      longitude: selected.longitude
    }));
  }, [formData.location, locations, mapReady]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.phone) newErrors.phone = 'Phone number is required';
    if (!formData.password) newErrors.password = 'Password is required';
    else if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    if (!formData.role) newErrors.role = 'Please select a role';
    if (!formData.location) newErrors.location = 'Please select a location';
    if (formData.latitude === '' || formData.longitude === '') newErrors.location = 'Please choose the location on the map';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
     e.preventDefault();


  if (validate()) {
    setIsSubmitting(true);

    try {
      // Exclude confirmPassword from data sent to the server
      const { confirmPassword, ...submitData } = formData;
      // console.log(formData);

      const response = await axios.post('/api/auth/register', submitData);

      // Handle success
      // alert(response.data.message); 
      setIsSubmitting(false);
      navigate('/login');
      // Redirect to login or home page
      // navigate('/login'); // if using React Router
    } catch (error) {
      console.error('Registration error:', error);
      if (error.response) {
        alert(error.response.data.message); // show backend error
      } else {
        alert('Something went wrong. Please try again.');
      }
      setIsSubmitting(false);
    }
  }
  };

  return (
    <div className="signup-container">
      <div className="signup-card">
        <div className="signup-header">
          <h2>Create Your Account</h2>
          <p>Join the municipal complaint management system</p>
        </div>

        <form onSubmit={handleSubmit} className="signup-form">
          {/* Full Name */}
          <div className={`form-group ${errors.fullName ? 'error' : ''}`}>
            <label htmlFor="fullName">Full Name</label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Enter your full name"
            />
            {errors.fullName && <span className="error-message">{errors.fullName}</span>}
          </div>

          {/* Email */}
          <div className={`form-group ${errors.email ? 'error' : ''}`}>
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>

          {/* Phone Number */}
          <div className={`form-group ${errors.phone ? 'error' : ''}`}>
            <label htmlFor="phone">Phone Number</label>
            <div className="phone-input">
              <select className="country-code">
                <option>+91</option>
                <option>+44</option>
                <option>+81</option>
              </select>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="Enter your phone number"
              />
            </div>
            {errors.phone && <span className="error-message">{errors.phone}</span>}
          </div>

          {/* Password */}
          <div className={`form-group ${errors.password ? 'error' : ''}`}>
            <label htmlFor="password">Password</label>
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Create a password"
              />
              <button 
                type="button" 
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <i className="fas fa-eye-slash"></i>
                ) : (
                  <i className="fas fa-eye"></i>
                )}
              </button>
            </div>
            {errors.password && <span className="error-message">{errors.password}</span>}
            <div className="password-hints">
              <span className={formData.password.length >= 8 ? 'valid' : ''}>
                <i className={`fas ${formData.password.length >= 8 ? 'fa-check' : 'fa-circle'}`}></i> 8+ characters
              </span>
            </div>
          </div>

          {/* Confirm Password */}
          <div className={`form-group ${errors.confirmPassword ? 'error' : ''}`}>
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              type={showPassword ? "text" : "password"}
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm your password"
            />
            {errors.confirmPassword && (
              <span className="error-message">{errors.confirmPassword}</span>
            )}
          </div>

          {/* Role */}
          <div className={`form-group ${errors.role ? 'error' : ''}`}>
            <label htmlFor="role">I am a</label>
            <select
              id="role"
              name="role"
              value={formData.role}
              onChange={handleChange}
            >
              <option value="citizen">Citizen</option>
              <option value="staff">Municipal Staff</option>
              <option value="admin">Admin</option>
            </select>
            {errors.role && <span className="error-message">{errors.role}</span>}
          </div>

          {/* Address */}
          <div className="form-group">
            <label htmlFor="address">Address (Optional)</label>
            <textarea
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Enter your full address"
              rows="3"
            ></textarea>
            <p className="helper-text">Helpful for location-based complaints</p>
          </div>

{/* Location (District Selection) */}
<div className={`form-group ${errors.location ? 'error' : ''}`}>
  <label htmlFor="location">Select Location</label>
  <select
    id="location"
    name="location"
    value={formData.location}
    onChange={handleChange}
  >
    <option value="">-- Select your city / location --</option>
    {locations.map((item) => (
      <option key={item.name} value={item.name}>{item.name}</option>
    ))}
  </select>
  {errors.location && <span className="error-message">{errors.location}</span>}

  <div className="location-map-card">
    <div className="map-heading">
      <div>
        <strong><i className="fas fa-map-marker-alt"></i> Pinpoint Your Location</strong>
        <small>Select a city above, then click or drag the pin to the exact location.</small>
      </div>
      {formData.latitude !== '' && (
        <span className="coordinates-badge">
          {formData.latitude}, {formData.longitude}
        </span>
      )}
    </div>
    <div ref={mapRef} className="signup-location-map" aria-label="Location map"></div>
  </div>
</div>



          {/* Terms Checkbox */}
          <div className="form-group checkbox-group">
            <input type="checkbox" id="terms" required />
            <label htmlFor="terms">
              I agree to the <Link to="/terms">Terms of Service</Link> and <Link to="/privacy">Privacy Policy</Link>
            </label>
          </div>

          {/* Submit Button */}
          <button 
            type="submit" 
            className="submit-btn"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <i className="fas fa-spinner fa-spin"></i> Creating Account...
              </>
            ) : (
              'Create Account'
            )}
          </button>

          <div className="login-link">
            Already have an account? <Link to="/login">Sign in</Link>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Signup;