import React from 'react';
import { Link } from 'react-router-dom';
import '../Styles/DemoHub.css';

const pages = [
  ['Home', '/', 'Public landing page'],
  ['About', '/about', 'Project overview'],
  ['Services', '/services', 'SCMS services'],
  ['Workflow', '/workflow', 'Complaint workflow'],
  ['Technology', '/technology', 'Technology used'],
  ['Contact', '/contact', 'Contact page'],
  ['Sign In', '/login', 'Normal authentication'],
  ['Sign Up', '/register', 'Citizen registration'],
];

const demos = [
  ['Citizen Dashboard', '/citizen?demo=1', 'Open without database/login'],
  ['Staff Dashboard', '/staff?demo=1', 'Open without database/login'],
  ['Admin Dashboard', '/admin?demo=1', 'Includes the real heatmap tab'],
  ['Complaint Heatmap', '/admin?demo=1&tab=heatmap', 'Interactive OpenStreetMap heatmap'],
  ['Complaint History', '/complaint-history?demo=1', 'Citizen complaint history'],
  ['Track Complaint', '/track-complaint?demo=1', 'Track a complaint'],
  ['Profile', '/profile?demo=1', 'Profile page'],
];

export default function DemoHub() {
  return (
    <div className="demo-hub">
      <header className="demo-header">
        <div><strong>SCMS</strong><span>Easy Page Viewer</span></div>
        <Link to="/" className="demo-home">← Home</Link>
      </header>
      <main className="demo-main">
        <section className="demo-hero">
          <span>SMART COMPLAINT MANAGEMENT SYSTEM</span>
          <h1>View every web page easily</h1>
          <p>Use the buttons below to open the public pages or demo dashboards. Demo dashboard links do not require a login.</p>
        </section>

        <h2>Frontend Pages</h2>
        <div className="demo-grid">
          {pages.map(([title, path, desc]) => <Link className="demo-card" to={path} key={path}><b>{title}</b><small>{desc}</small></Link>)}
        </div>

        <h2>Dashboard & Heatmap Demo</h2>
        <div className="demo-grid">
          {demos.map(([title, path, desc]) => <Link className="demo-card dashboard" to={path} key={path}><b>{title}</b><small>{desc}</small></Link>)}
        </div>

        <div className="demo-help">
          <b>Recommended:</b> Start the backend and frontend with <code>START_ALL.bat</code>, then open <code>http://localhost:3000/demo</code>.
        </div>
      </main>
    </div>
  );
}
