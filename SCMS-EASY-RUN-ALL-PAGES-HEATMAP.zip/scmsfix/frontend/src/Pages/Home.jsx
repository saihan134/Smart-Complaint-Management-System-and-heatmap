import React from 'react';
import { Link } from 'react-router-dom';
import '../Styles/Home.css';

function Home() {
  return (
    <div className="municipal-app">
      <nav className="navbar">
        <div className="container nav-container">
          <Link to="/" className="brand-logo">
            <img src="/scms-logo.svg" alt="SCMS Logo" />
            <div>
              <strong>SCMS</strong>
              <span>Smart Complaint Management</span>
            </div>
          </Link>

          <div className="nav-links">
            <Link className="active" to="/">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/services">Services</Link>
            <Link to="/contact">Contact</Link>
            <div className="auth-buttons">
              <Link to="/login" className="btn btn-outline">Sign In</Link>
              <Link to="/register" className="btn btn-primary">Sign Up</Link>
            </div>
          </div>
        </div>
      </nav>

      <section className="hero">
        <div className="hero-glow hero-glow-one"></div>
        <div className="hero-glow hero-glow-two"></div>
        <div className="container hero-container">
          <div className="hero-content">
            <div className="hero-badge">✦ SMART CITY • DIGITAL CIVIC SERVICES</div>
            <h1>Your Voice <span>Matters.</span><br />We Make Cities Better.</h1>
            <p className="subtitle">
              Report civic issues, track complaints in real time, and stay connected
              with the people responsible for making your community better.
            </p>

            <div className="cta-buttons">
              <Link to="/report" className="btn btn-primary btn-large">
                <span>📢</span> Report an Issue
              </Link>
              <Link to="/track" className="btn btn-white btn-large">
                <span>🔎</span> Track Complaint
              </Link>
            </div>

            <div className="trust-row">
              <span>✓ Fast reporting</span>
              <span>✓ Live status updates</span>
              <span>✓ Transparent resolution</span>
            </div>
          </div>

          <div className="hero-visual">
            <div className="hero-image-wrap">
              <img
                src="https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=1200&q=85"
                alt="Modern city and community"
              />
              <div className="floating-card card-top">
                <span className="floating-icon blue">✓</span>
                <div><strong>15,000+</strong><small>Issues resolved</small></div>
              </div>
              <div className="floating-card card-bottom">
                <span className="floating-icon green">⚡</span>
                <div><strong>24/7</strong><small>Complaint tracking</small></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <div className="section-heading">
            <span className="section-kicker">SIMPLE • FAST • TRANSPARENT</span>
            <h2>How SCMS Works</h2>
            <p>From reporting an issue to getting it resolved, everything stays in one place.</p>
          </div>

          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon icon-blue">01</div>
              <h3>Report an Issue</h3>
              <p>Submit potholes, garbage, streetlight, water and other civic complaints with useful details.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon icon-purple">02</div>
              <h3>Track in Real Time</h3>
              <p>Follow every complaint from pending to in-progress and finally to resolution.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon icon-cyan">03</div>
              <h3>Get It Resolved</h3>
              <p>Receive updates from staff and know when your reported issue has been addressed.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="visual-banner">
        <div className="container visual-banner-grid">
          <div>
            <span className="section-kicker light-kicker">CONNECTED COMMUNITIES</span>
            <h2>Technology that brings citizens and city teams together.</h2>
            <p>
              A modern digital workflow helps departments respond faster while citizens
              get visibility into every step of their complaint.
            </p>
            <Link to="/about" className="btn btn-white">Explore SCMS →</Link>
          </div>
          <img
            src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=85"
            alt="Connected urban community"
          />
        </div>
      </section>

      <section className="stats">
        <div className="container stats-grid">
          <div className="stat-item"><h3>15K+</h3><p>Issues Resolved</p></div>
          <div className="stat-item"><h3>24h</h3><p>Average Response</p></div>
          <div className="stat-item"><h3>92%</h3><p>Citizen Satisfaction</p></div>
          <div className="stat-item"><h3>50+</h3><p>Departments</p></div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container">
          <div className="section-heading">
            <span className="section-kicker">CITIZEN FEEDBACK</span>
            <h2>What Citizens Say</h2>
          </div>
          <div className="testimonial-card">
            <div className="quote-mark">“</div>
            <p>
              I reported a pothole and could follow the entire process online.
              The tracking feature made the resolution feel transparent and easy.
            </p>
            <div className="testimonial-author">
              <img src="https://randomuser.me/api/portraits/women/43.jpg" alt="Citizen" />
              <div><strong>Sarah J.</strong><span>Resident • Downtown District</span></div>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container">
          <div className="cta-icon"><img src="/scms-logo.svg" alt="SCMS" /></div>
          <h2>Ready to Improve Your Community?</h2>
          <p>Join citizens using SCMS to report problems and create cleaner, safer and smarter neighborhoods.</p>
          <Link to="/register" className="btn btn-primary btn-large">Create Your Account →</Link>
        </div>
      </section>

      <footer className="footer">
        <div className="container footer-grid">
          <div className="footer-col footer-brand">
            <img src="/scms-logo.svg" alt="SCMS Logo" />
            <div><h3>SCMS</h3><p>Smart Complaint Management System for responsive digital communities.</p></div>
          </div>
          <div className="footer-col">
            <h4>Explore</h4>
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/services">Services</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <div className="footer-col">
            <h4>Platform</h4>
            <Link to="/login">Citizen Login</Link>
            <Link to="/register">Create Account</Link>
            <Link to="/track">Track Complaint</Link>
          </div>
          <div className="footer-col">
            <h4>Contact</h4>
            <span>contact@scms.gov</span>
            <span>+91 1800 123 4567</span>
            <span>Digital Civic Services</span>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} SCMS. Built for smarter communities.</div>
      </footer>
    </div>
  );
}

export default Home;
