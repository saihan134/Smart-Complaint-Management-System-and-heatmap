import React from "react";
import { Link } from "react-router-dom";
import "../Styles/AboutProject.css";

const services = [
  ["📝", "Complaint Reporting", "Citizens can submit civic complaints with title, category, description, location and supporting files."],
  ["📍", "Location-Based Logging", "Record where a problem occurred using manual or automatic location information."],
  ["📋", "Complaint Tracking", "Track complaints through Pending, In Progress and Resolved stages."],
  ["🔔", "Status Updates", "Keep citizens informed when staff changes complaint status or adds remarks."],
  ["📊", "Analytics & Reports", "Administrators can inspect trends, categories, resolution time and location data."],
  ["👥", "User Management", "Role-based access supports citizens, staff and administrators."]
];

export default function Services() {
  return (
    <div className="simple-page">
      <nav className="about-nav">
        <Link className="brand" to="/"><img src="/scms-logo.svg" alt="SCMS Logo" /><span className="brand-text">SCMS</span><small>Smart Complaint Management</small></Link>
        <div className="nav-links">
          <Link to="/about">About</Link>
          <Link className="active" to="/services">Services</Link>
          <Link to="/workflow">Workflow</Link>
          <Link to="/technology">Technology</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <main className="section">
        <div className="section-heading">
          <p className="eyebrow">SERVICES</p>
          <h1>What SCMS provides</h1>
          <p>A complete digital workflow for reporting and resolving civic issues.</p>
        </div>
        <div className="info-grid">
          {services.map(([icon, title, text]) => (
            <article className="info-card" key={title}>
              <span>{icon}</span><h3>{title}</h3><p>{text}</p>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}
