import React, { useState, useEffect } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import '../Styles/Signin.css';
import axios from 'axios';

function Signin() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
    const navigate = useNavigate();

 useEffect(() => {
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user'));

  if (token && user) {
    if (user.role === 'citizen') {
      navigate('/citizen');
    } else if (user.role === 'staff') {
      navigate('/staff');
    }
  }
}, [navigate]);



  const handleChange = (e) => {

    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
    if (loginError) setLoginError('');
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.password) newErrors.password = 'Password is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
     e.preventDefault();

  if (validate()) {
    setIsSubmitting(true);
    setLoginError('');

    try {
      const response = await axios.post('/api/auth/login', {
        email: formData.email,
        password: formData.password
      });

      // Save token to localStorage
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));

      // alert('Login successful!');

      setIsSubmitting(false);
      if (response.data.user.role === 'citizen') {
  navigate('/citizen');
} else if (response.data.user.role === 'staff') {
  navigate('/staff');

} else if (response.data.user.role === 'admin') {
  navigate('/admin');
}

      
      // Redirect to dashboard based on role
      // navigate('/dashboard'); // use useNavigate() from react-router-dom
    } catch (error) {
      setIsSubmitting(false);
      if (error.response) {
        setLoginError(error.response.data.message);
      } else {
        setLoginError('Something went wrong. Please try again.');
      }
    }
  }
  };

  return (
    <div className="signin-container">
      <div className="signin-card">
        <div className="signin-header">
          <div className="logo">
            <span className="logo-icon">🏛️</span>
            <span>CityCare</span>
          </div>
          <h2>Welcome Back</h2>
          <p>Sign in to your municipal account</p>
        </div>

        {loginError && (
          <div className="alert alert-error">
            <i className="fas fa-exclamation-circle"></i>
            {loginError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="signin-form">
          {/* Email */}
          <div className={`form-group ${errors.email ? 'error' : ''}`}>
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              autoComplete="username"
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>

          {/* Password */}
          <div className={`form-group ${errors.password ? 'error' : ''}`}>
            <div className="password-label-row">
              <label htmlFor="password">Password</label>
              <Link to="/forgot-password" className="forgot-password">
                Forgot password?
              </Link>
            </div>
            <div className="password-input">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter your password"
                autoComplete="current-password"
              />
              <button 
                type="button" 
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <i className="fas fa-eye-slash"></i>
                ) : (
                  <i className="fas fa-eye"></i>
                )}
              </button>
            </div>
            {errors.password && <span className="error-message">{errors.password}</span>}
          </div>

          {/* Remember Me */}
          <div className="signin-form-group remember-me">
            <input
              type="checkbox"
              id="rememberMe"
              name="rememberMe"
              checked={formData.rememberMe}
              onChange={handleChange}
            />
            <label htmlFor="rememberMe">Remember me</label>
          </div>

          {/* Submit Button */}
          <button 
            type="submit" 
            className="submit-btn"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <i className="fas fa-spinner fa-spin"></i> Signing In...
              </>
            ) : (
              'Sign In'
            )}
          </button>

          <div className="signup-link">
            Don't have an account? <Link to="/register">Sign up</Link>
          </div>
        </form>

        {/* <div className="social-login">
          <div className="divider">
            <span>Or sign in with</span>
          </div>
          <div className="social-buttons">
            <button type="button" className="social-btn google">
              <i className="fab fa-google"></i> Google
            </button>
            <button type="button" className="social-btn microsoft">
              <i className="fab fa-microsoft"></i> Microsoft
            </button>
          </div>
        </div> */}
      </div>
    </div>
  );
}

export default Signin;