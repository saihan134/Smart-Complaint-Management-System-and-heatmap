import React from "react";
import { Link } from "react-router-dom";
import "../Styles/AboutProject.css";

export default function Workflow() {
  return (
    <div className="simple-page">
      <nav className="about-nav">
        <Link className="brand" to="/">🏙️ CityCare <span>SCMS</span></Link>
        <div className="nav-links">
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link className="active" to="/workflow">Workflow</Link>
          <Link to="/technology">Technology</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <main className="section">
        <div className="section-heading">
          <p className="eyebrow">WORKFLOW</p>
          <h1>How SCMS works</h1>
        </div>
        <div className="workflow-box">
          {[
            ["1", "Citizen Registration/Login", "Users authenticate before accessing protected complaint features."],
            ["2", "Create Complaint", "The citizen enters title, category, description, date and location and can attach files."],
            ["3", "Staff Processing", "Staff members review complaints and update the status."],
            ["4", "Resolution", "The issue progresses to Resolved after action is completed."],
            ["5", "Administration", "Admin dashboards provide user management, complaint monitoring and analytics."]
          ].map(([n, title, text]) => (
            <div className="workflow-step" key={n}>
              <div className="step-number">{n}</div>
              <div><h3>{title}</h3><p>{text}</p></div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
