import React from "react";
import { Link } from "react-router-dom";
import "../Styles/AboutProject.css";

export default function AboutProject() {
  return (
    <div className="about-page">
      <nav className="about-nav">
        <Link className="brand" to="/"><img src="/scms-logo.svg" alt="SCMS Logo" /><span className="brand-text">SCMS</span><small>Smart Complaint Management</small></Link>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link className="active" to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/workflow">Workflow</Link>
          <Link to="/technology">Technology</Link>
          <Link to="/contact">Contact</Link>
        </div>
        <div className="nav-actions">
          <Link className="btn outline" to="/login">Sign In</Link>
          <Link className="btn primary" to="/register">Sign Up</Link>
        </div>
      </nav>

      <header className="about-hero">
        <div>
          <p className="eyebrow">SMART CITY • CIVIC TECHNOLOGY</p>
          <h1>Smart Complaint Management System</h1>
          <p>
            SCMS is a web-based platform that helps citizens report municipal
            problems, track complaints, and receive updates while staff and
            administrators manage resolution efficiently.
          </p>
          <div className="hero-buttons">
            <Link className="btn primary large" to="/register">Report an Issue</Link>
            <Link className="btn glass large" to="/workflow">View Workflow</Link>
          </div>
        </div>
        <div className="hero-card">
          <img
            className="about-hero-image"
            src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=900&q=85"
            alt="Smart city"
          />
          <div className="city-icon">🏙️</div>
          <h3>One platform for civic problems</h3>
          <p>Potholes • Waste • Streetlights • Water • Roads • Public services</p>
        </div>
      </header>

      <section className="section">
        <div className="section-heading">
          <p className="eyebrow">ABOUT THE PROJECT</p>
          <h2>Making complaint resolution simple and transparent</h2>
          <p>
            The system connects citizens, municipal staff, and administrators
            through role-based dashboards and a centralized complaint database.
          </p>
        </div>

        <div className="info-grid">
          <article className="info-card">
            <span>🎯</span>
            <h3>Objective</h3>
            <p>
              Digitize municipal complaint registration, assignment, tracking,
              communication, and resolution.
            </p>
          </article>
          <article className="info-card">
            <span>⚡</span>
            <h3>Efficiency</h3>
            <p>
              Reduce manual work by organizing complaints and giving staff a
              structured workflow for updates.
            </p>
          </article>
          <article className="info-card">
            <span>🔎</span>
            <h3>Transparency</h3>
            <p>
              Citizens can monitor complaint status instead of depending on
              repeated visits or phone calls.
            </p>
          </article>
          <article className="info-card">
            <span>📊</span>
            <h3>Data Insights</h3>
            <p>
              Administrators can monitor complaint trends, categories,
              resolution times, users, and staff activity.
            </p>
          </article>
        </div>
      </section>

      <section className="dark-section">
        <div className="section-heading light">
          <p className="eyebrow">ROLE-BASED SYSTEM</p>
          <h2>Three users, one connected platform</h2>
        </div>
        <div className="role-grid">
          <article className="role-card">
            <div className="role-icon">👤</div>
            <h3>Citizen</h3>
            <ul>
              <li>Create an account</li>
              <li>Submit complaints</li>
              <li>Attach complaint files</li>
              <li>Track status</li>
              <li>View complaint history</li>
            </ul>
          </article>
          <article className="role-card">
            <div className="role-icon">🧑‍💼</div>
            <h3>Staff</h3>
            <ul>
              <li>View assigned complaints</li>
              <li>Update complaint status</li>
              <li>Add remarks</li>
              <li>Manage resolution progress</li>
              <li>Communicate updates</li>
            </ul>
          </article>
          <article className="role-card">
            <div className="role-icon">🛡️</div>
            <h3>Administrator</h3>
            <ul>
              <li>Monitor all complaints</li>
              <li>Manage users</li>
              <li>View analytics</li>
              <li>Export reports</li>
              <li>Monitor system performance</li>
            </ul>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <p className="eyebrow">SYSTEM WORKFLOW</p>
          <h2>From citizen report to resolution</h2>
        </div>
        <div className="timeline">
          {[
            ["01", "Submit", "Citizen submits a complaint with category, description and location."],
            ["02", "Categorize", "The complaint is organized so it can be handled by the relevant team."],
            ["03", "Process", "Staff reviews the issue and updates its progress."],
            ["04", "Resolve", "The complaint is marked resolved after the issue is addressed."],
            ["05", "Analyze", "Administrators use analytics and reports to improve services."]
          ].map(([number, title, text]) => (
            <div className="timeline-item" key={number}>
              <div className="timeline-number">{number}</div>
              <div><h3>{title}</h3><p>{text}</p></div>
            </div>
          ))}
        </div>
      </section>

      <footer className="about-footer">
        <div>
          <h3>Smart Complaint Management System</h3>
          <p>Building a more responsive and accountable digital city.</p>
        </div>
        <p>Developed by <strong>TechnoFoasters</strong></p>
      </footer>
    </div>
  );
}
