import React from "react";
import { Link } from "react-router-dom";
import "../Styles/AboutProject.css";

const stack = [
  ["React.js", "Frontend UI and role-based pages"],
  ["JavaScript / HTML / CSS", "Client-side application and responsive styling"],
  ["Axios", "Communication between frontend and REST APIs"],
  ["Node.js", "Backend JavaScript runtime"],
  ["Express.js", "REST API and server-side routing"],
  ["MongoDB", "Database for users and complaints"],
  ["Mongoose", "MongoDB object modeling"],
  ["JWT", "Authentication and protected access"],
  ["Cloudinary", "Media/file upload integration"],
  ["Recharts / XLSX", "Analytics visualization and report export"]
];

export default function Technology() {
  return (
    <div className="simple-page">
      <nav className="about-nav">
        <Link className="brand" to="/">🏙️ CityCare <span>SCMS</span></Link>
        <div className="nav-links">
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/workflow">Workflow</Link>
          <Link className="active" to="/technology">Technology</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <main className="section">
        <div className="section-heading">
          <p className="eyebrow">TECHNOLOGY STACK</p>
          <h1>Built with modern web technologies</h1>
        </div>
        <div className="tech-grid">
          {stack.map(([name, use]) => (
            <article className="tech-card" key={name}>
              <h3>{name}</h3><p>{use}</p>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}
