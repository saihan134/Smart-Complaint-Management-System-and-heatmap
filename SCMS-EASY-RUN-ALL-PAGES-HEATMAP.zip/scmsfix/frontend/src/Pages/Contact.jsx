import React from "react";
import { Link } from "react-router-dom";
import "../Styles/AboutProject.css";

export default function Contact() {
  const submit = (e) => {
    e.preventDefault();
    alert("Thank you! Your message has been submitted.");
  };

  return (
    <div className="simple-page">
      <nav className="about-nav">
        <Link className="brand" to="/">🏙️ CityCare <span>SCMS</span></Link>
        <div className="nav-links">
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/workflow">Workflow</Link>
          <Link to="/technology">Technology</Link>
          <Link className="active" to="/contact">Contact</Link>
        </div>
      </nav>
      <main className="contact-section">
        <div>
          <p className="eyebrow">CONTACT</p>
          <h1>Have a question about SCMS?</h1>
          <p>Use the form to send a message to the project team.</p>
          <div className="contact-details">
            <p>📧 support@citycare.example</p>
            <p>🏢 Smart City Digital Services</p>
            <p>🕘 Monday – Friday, 9:00 AM – 5:00 PM</p>
          </div>
        </div>
        <form className="contact-form" onSubmit={submit}>
          <input required placeholder="Your name" />
          <input required type="email" placeholder="Email address" />
          <input required placeholder="Subject" />
          <textarea required rows="6" placeholder="Your message" />
          <button className="btn primary" type="submit">Send Message</button>
        </form>
      </main>
    </div>
  );
}
