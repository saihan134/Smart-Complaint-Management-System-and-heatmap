import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';

import Login from './Pages/Signin';
import Register from './Pages/Signup';
import Home from './Pages/Home';
import AboutProject from './Pages/AboutProject';
import Services from './Pages/Services';
import Workflow from './Pages/Workflow';
import Technology from './Pages/Technology';
import Contact from './Pages/Contact';
import DashboardCitizen from './Dashboards/DashboardCitizen';
import ComplaintHistory from './Components/ComplaintHistory';
import TrackComplaint from './Components/TrackComplaint';
import ProfilePage from './Components/ProfilePage';
import StaffDashboard from './Dashboards/StaffDashboard';
import AdminDashboard from './Dashboards/AdminDashboard';
import DemoHub from './Pages/DemoHub';

function readUser() {
  try {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  } catch {
    localStorage.removeItem('user');
    return null;
  }
}

function App() {
  const [user, setUser] = useState(readUser);
  const location = useLocation();

  useEffect(() => {
    const syncUser = () => setUser(readUser());
    const params = new URLSearchParams(location.search);
    const demo = params.get('demo') === '1';
    if (demo) {
      const role = location.pathname.includes('/admin') ? 'admin' : location.pathname.includes('/staff') ? 'staff' : 'citizen';
      const demoUser = {
        id: `demo-${role}-001`,
        _id: `demo-${role}-001`,
        fullName: `Demo ${role.charAt(0).toUpperCase() + role.slice(1)}`,
        email: `${role}@scms.local`,
        role,
        location: 'Chennai'
      };
      localStorage.setItem('user', JSON.stringify(demoUser));
      localStorage.setItem('scmsDemo', '1');
      setUser(demoUser);
    } else {
      if (localStorage.getItem('scmsDemo') === '1') {
        localStorage.removeItem('user');
        localStorage.removeItem('token');
        localStorage.removeItem('scmsDemo');
      }
      syncUser();
    }
    window.addEventListener('storage', syncUser);
    window.addEventListener('scms-auth-change', syncUser);
    return () => {
      window.removeEventListener('storage', syncUser);
      window.removeEventListener('scms-auth-change', syncUser);
    };
  }, [location.pathname, location.search]);

  const params = new URLSearchParams(location.search);
  const demoRole = params.get('demo') === '1' ? (location.pathname.includes('/admin') ? 'admin' : location.pathname.includes('/staff') ? 'staff' : 'citizen') : null;
  const dashboardForRole = user?.role ? `/${user.role}` : '/login';
  const demoAccess = params.get('demo') === '1';

  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to={dashboardForRole} replace /> : <Home />} />
      <Route path="/login" element={user ? <Navigate to={dashboardForRole} replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to={dashboardForRole} replace /> : <Register />} />

      {/* Public project information pages */}
      <Route path="/about" element={<AboutProject />} />
      <Route path="/services" element={<Services />} />
      <Route path="/workflow" element={<Workflow />} />
      <Route path="/technology" element={<Technology />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/demo" element={<DemoHub />} />

      {/* Citizen */}
      <Route path="/citizen" element={demoAccess || user?.role === 'citizen' ? <DashboardCitizen /> : <Navigate to="/login" replace />} />
      <Route path="/complaint-history" element={demoAccess || user?.role === 'citizen' ? <ComplaintHistory /> : <Navigate to="/login" replace />} />
      <Route path="/track-complaint" element={demoAccess || user?.role === 'citizen' ? <TrackComplaint /> : <Navigate to="/login" replace />} />

      {/* Shared */}
      <Route path="/profile" element={demoAccess || user ? <ProfilePage /> : <Navigate to="/login" replace />} />

      {/* Staff/Admin */}
      <Route path="/staff" element={demoRole === 'staff' || user?.role === 'staff' ? <StaffDashboard /> : <Navigate to="/login" replace />} />
      <Route path="/admin" element={demoRole === 'admin' || user?.role === 'admin' ? <AdminDashboard /> : <Navigate to="/login" replace />} />

      {/* Friendly aliases used by the home page */}
      <Route path="/track" element={<Navigate to="/track-complaint" replace />} />
      <Route path="/report" element={user?.role === 'citizen' ? <DashboardCitizen /> : <Navigate to="/login" replace />} />

      {/* Unknown routes */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
