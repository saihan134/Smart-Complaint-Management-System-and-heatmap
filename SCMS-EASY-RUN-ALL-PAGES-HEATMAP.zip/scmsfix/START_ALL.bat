@echo off
setlocal
cd /d "%~dp0"

echo ==================================================
echo   SMART COMPLAINT MANAGEMENT SYSTEM - START ALL
echo ==================================================
echo.

if not exist "backend\.env" (
  echo Creating backend\.env from .env.example...
  copy /Y "backend\.env.example" "backend\.env" >nul
)

if not exist "backend\node_modules" (
  echo Installing backend dependencies. This happens only once...
  pushd "backend"
  call npm.cmd install
  if errorlevel 1 goto install_error
  popd
)

if not exist "frontend\node_modules" (
  echo Installing frontend dependencies. This happens only once...
  pushd "frontend"
  call npm.cmd install
  if errorlevel 1 goto install_error
  popd
)

echo Starting backend in a new window...
start "SCMS Backend" /D "%~dp0backend" cmd /k npm.cmd start

timeout /t 3 /nobreak >nul

echo Starting frontend in a new window...
start "SCMS Frontend" /D "%~dp0frontend" cmd /k npm.cmd start

echo.
echo Waiting 12 seconds for React to start...
timeout /t 12 /nobreak >nul
start "" "http://localhost:3000/demo"
echo.
echo Page viewer: http://localhost:3000/demo
echo Backend:     http://localhost:5000/
echo Health:      http://localhost:5000/api/health
echo.
echo Keep both black terminal windows open.
pause
exit /b 0

:install_error
echo.
echo ERROR: npm installation failed. Check your internet connection and Node.js installation.
pause
exit /b 1
